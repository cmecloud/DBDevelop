﻿/*
Post-Deployment Script Template							
--------------------------------------------------------------------------------------
 This file contains SQL statements that will be appended to the build script.		
 Use SQLCMD syntax to include a file in the post-deployment script.			
 Example:      :r .\myfile.sql								
 Use SQLCMD syntax to reference a variable in the post-deployment script.		
 Example:      :setvar TableName MyTable							
               SELECT * FROM [$(TableName)]					
--------------------------------------------------------------------------------------
*/

:r ".\POST\Post-DimAudit-Insert.sql"
:r ".\POST\Post-DimAddress-Insert.sql"
:r ".\POST\Post-DimCompany-Insert.sql"
:r ".\POST\Post-DimCurrency-Insert.sql"
:r ".\POST\Post-DimDate-Insert.sql"
:r ".\POST\Post-DimLedgerAccount-Insert.sql"
:r ".\POST\Post-DimLedgerTransaction-Insert.sql"
:r ".\POST\Post-DimLocation-Insert.sql"
:r ".\POST\Post-DimItem-Insert.sql"
:r ".\POST\Post-DimSalesGroup-Insert.sql"
:r ".\POST\Post-DimCustomer-Insert.sql"
:r ".\POST\Post-DimTransaction-Insert.sql"

:r ".\POST\Post-FactBudget-Insert.sql"
:r ".\POST\Post-FactExchangeRate-Insert.sql"
:r ".\POST\Post-FactLedgerBalance-Insert.sql"
:r ".\POST\Post-FactSalesInvoiceLine-Insert.sql"
:r ".\POST\Post-FactSalesOrderLine-Insert.sql"
