/******************************************************
  *
  * Name:         Stage-FactLedgerBalance-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [FactLedgerBalance]
  *               in the [Stage] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Stage].[FactLedgerBalance] (
   [FactLedgerBalanceKey] BIGINT NOT NULL
,  [DateKey] INT NOT NULL
,  [CompanyKey] INT NOT NULL
,  [AccountKey] INT NOT NULL
,  [LedgerTransactionKey] INT NOT NULL
,  [TransactionKey] INT NOT NULL
,  [InsertAuditKey] INT NOT NULL
,  [UpdateAuditKey] INT NOT NULL
,  [DebitAmount] MONEY NULL
,  [CreditAmount] MONEY NULL
,  [Quantity] NUMERIC(28,12) NULL
, [HashKey] AS (CONVERT([VARBINARY](16), HASHBYTES('MD5', CONCAT([AccountKey], ''))))
, [HashNonKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat(
    IsNull([DateKey], -1)
,   IsNull([CompanyKey], -1)
,   IsNull([AccountKey], -1)
,   IsNull([LedgerTransactionKey], -1)
,   IsNull([TransactionKey], -1)
,   IsNull([InsertAuditKey], -1)
,   IsNull([UpdateAuditKey], -1)
,   IsNull([DebitAmount], 0)
,   IsNull([CreditAmount], 0.0)
,   IsNull([Quantity], 0.0)
, ''))))
, CONSTRAINT [PK_Stage_FactLedgerBalance] PRIMARY KEY CLUSTERED 
( [FactLedgerBalanceKey] )
) 
;

