/******************************************************
  *
  * Name:         Stage-DimCustomer-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimCustomer]
  *               in the [Stage] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Stage].[DimCustomer] (
   [CustomerKey] int NOT NULL
,  [CustomerID] nvarchar(24) NOT NULL
,  [Customer] nvarchar(60) NOT NULL
,  [CustomerLongName] nvarchar(86) NOT NULL
,  [CustomerSearchName] nvarchar(30) NOT NULL
,  [CompanyKey] int NOT NULL
,  [CommonCustomerKey] int NOT NULL
,  [ShipToAddressKey] int NOT NULL
,  [BillToAddressKey] int NOT NULL
,  [CurrencyKey] int NOT NULL
,  [SalesGroupKey] int NOT NULL
,  [CustomerCode] nvarchar(15) NOT NULL
,  [CustomerCodeName] nvarchar(30) NOT NULL
,  [CommonCustomerID] nvarchar(24) NOT NULL
,  [CommonCustomerName] nvarchar(60) NOT NULL
,  [CustomerCategoryID] nvarchar(15) NOT NULL
,  [CustomerCategoryName] nvarchar(30) NOT NULL
,  [CustomerGroup] nvarchar(30) NOT NULL
,  [PhoneNumber] nvarchar(20) NOT NULL
,  [FaxNumber] nvarchar(20) NOT NULL
,  [CellNumber] nvarchar(20) NOT NULL
,  [ContactName] nvarchar(60) NOT NULL
,  [ContactPhone] nvarchar(20) NOT NULL
,  [ContactEmail] nvarchar(80) NOT NULL
,  [MainContact] nvarchar(20) NOT NULL
,  [DateOpened] date NOT NULL
,  [BusinessLine] nvarchar(15) NOT NULL
,  [AccountType] nvarchar(15) NOT NULL
,  [Purpose] nvarchar(15) NOT NULL
,  [Segment] nvarchar(20) NOT NULL
,  [Language] nvarchar(7) NOT NULL
,  [RegionalSalesManager] nvarchar(10) NOT NULL
,  [CommissionGroup] nvarchar(10) NOT NULL
,  [PriceGroup] nvarchar(10) NOT NULL
,  [ItemGroup] nvarchar(10) NOT NULL
,  [CollectorCode] nvarchar(10) NOT NULL
,  [TaxGroup] nvarchar(11) NOT NULL
,  [TaxResaleNumber] nvarchar(20) NOT NULL
,  [TaxExpiration] date NOT NULL
,  [PaymentTermID] nvarchar(20) NOT NULL
,  [PaymentTermName] nvarchar(60) NOT NULL
,  [Discount] nvarchar(20) NOT NULL
,  [LineDiscount] nvarchar(10) NOT NULL
,  [CreditLimit] money NOT NULL
,  [CreditManager] nvarchar(10) NOT NULL
,  [CreditRating] nvarchar(10) NOT NULL
,  [CreditRiskType] nvarchar(20) NOT NULL
,  [CreditBin] nvarchar(15) NOT NULL
,  [CreditParentBin] nvarchar(15) NOT NULL
,  [CustomerParent] nvarchar(60) NOT NULL
,  [RebateCode] nvarchar(10) NOT NULL
,  [Rebate] numeric(8,3) NOT NULL
,  [MethodOfPayment] nvarchar(10) NOT NULL
,  [Stopped] nvarchar(10) NOT NULL
,  [AccountStatement] nvarchar(10) NOT NULL
,  [Flag] nvarchar(10) NOT NULL
,  [SpecialInstructions] nvarchar(500) NOT NULL
,  [ExcludeFromInterest] bit NOT NULL
,  [PrintInvoice] bit NOT NULL
,  [IsNational] bit NOT NULL
,  [IsArchived] bit NOT NULL
,  [IsCurrent] bit NOT NULL
,  [FromDate] datetime NOT NULL
,  [ToDate] datetime  DEFAULT '12/31/9999' NOT NULL
,  [RowChangeReason] nvarchar(200) NOT NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
, [HashKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat([CustomerID], ''))))
, [HashNonKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat(
    IsNull([CustomerID], '.')
,   IsNull([Customer], '.')
,   IsNull([CustomerLongName], '.')
,   IsNull([CustomerSearchName], '.')
,   IsNull([CompanyKey], -1)
,   IsNull([CommonCustomerKey], -1)
,   IsNull([ShipToAddressKey], -1)
,   IsNull([BillToAddressKey], -1)
,   IsNull([CurrencyKey], -1)
,   IsNull([SalesGroupKey], -1)
,   IsNull([CustomerCode], '.')
,   IsNull([CustomerCodeName], '.')
,   IsNull([CommonCustomerID], '.')
,   IsNull([CommonCustomerName], '.')
,   IsNull([CustomerCategoryID], '.')
,   IsNull([CustomerCategoryName], '.')
,   IsNull([CustomerGroup], '.')
,   IsNull([PhoneNumber], '.')
,   IsNull([FaxNumber], '.')
,   IsNull([CellNumber], '.')
,   IsNull([ContactName], '.')
,   IsNull([ContactPhone], '.')
,   IsNull([ContactEmail], '.')
,   IsNull([MainContact], '.')
,   IsNull([DateOpened], '12/31/1899')
,   IsNull([BusinessLine], '.')
,   IsNull([AccountType], '.')
,   IsNull([Purpose], '.')
,   IsNull([Segment], '.')
,   IsNull([Language], '.')
,   IsNull([RegionalSalesManager], '.')
,   IsNull([CommissionGroup], '.')
,   IsNull([PriceGroup], '.')
,   IsNull([ItemGroup], '.')
,   IsNull([CollectorCode], '.')
,   IsNull([TaxGroup], '.')
,   IsNull([TaxResaleNumber], '.')
,   IsNull([TaxExpiration], '12/31/1899')
,   IsNull([PaymentTermID], '.')
,   IsNull([PaymentTermName], '.')
,   IsNull([Discount], '.')
,   IsNull([LineDiscount], '.')
,   IsNull([CreditLimit], 0.0)
,   IsNull([CreditManager], '.')
,   IsNull([CreditRating], '.')
,   IsNull([CreditRiskType], '.')
,   IsNull([CreditBin], '.')
,   IsNull([CreditParentBin], '.')
,   IsNull([CustomerParent], '.')
,   IsNull([RebateCode], '.')
,   IsNull([Rebate], 0.0)
,   IsNull([MethodOfPayment], '.')
,   IsNull([Stopped], '.')
,   IsNull([AccountStatement], '.')
,   IsNull([Flag], '.')
,   IsNull([SpecialInstructions], '.')
,   IsNull([ExcludeFromInterest], -1)
,   IsNull([PrintInvoice], -1)
,   IsNull([IsNational], 0)
,   IsNull([IsArchived], 0)
,   IsNull([IsCurrent], 0)
,   IsNull([FromDate], '12/31/1899')
,   IsNull([ToDate], '12/31/1899')
,   IsNull([RowChangeReason], '.')
,   IsNull([InsertAuditKey], -1)
,   IsNull([UpdateAuditKey], -1)
, ''))))
, CONSTRAINT [PK_Stage_DimCustomer] PRIMARY KEY CLUSTERED 
( [CustomerKey] )
) 
;

