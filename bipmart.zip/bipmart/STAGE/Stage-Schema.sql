﻿/******************************************************
 *
 * Name:         Stage-Schema.sql
 *     
 * Design Phase:
 *     Author:   John Miner
 *     Date:     07-01-2018
 *     Purpose:  Create the [Stage] schema.
 * 
 ******************************************************/

CREATE SCHEMA [Stage] AUTHORIZATION [dbo];
GO