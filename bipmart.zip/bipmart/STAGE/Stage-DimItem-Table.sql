/******************************************************
  *
  * Name:         Stage-DimItem-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimItem]
  *               in the [Stage] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Stage].[DimItem] (
   [ItemKey] int NOT NULL
,  [ItemID] nvarchar(24) NOT NULL
,  [ItemName] nvarchar(60) NOT NULL
,  [ItemText] nvarchar(1000) NOT NULL
,  [ItemSearchName] nvarchar(30) NULL
,  [LocationKey] int NOT NULL
,  [SubCategoryID] nvarchar(15) NOT NULL
,  [SubCategory] nvarchar(60) NULL
,  [CategoryID] nvarchar(15) NULL
,  [Category] nvarchar(60) NULL
,  [ProductClassID] nvarchar(10) NULL
,  [ProductClass] nvarchar(60) NULL
,  [SalesClassID] nvarchar(10) NULL
,  [SalesClass] nvarchar(60) NULL
,  [PurposeKey] nvarchar(15) NULL
,  [BusinessLineKey] nvarchar(15) NULL
,  [ItemGroupID] nvarchar(10) NULL
,  [FormGroup] nvarchar(20) NULL
,  [CommissionGroup] nvarchar(10) NULL
,  [DimensionGroup] nvarchar(10) NULL
,  [ModelGroup] nvarchar(10) NULL
,  [BuyerGroup] nvarchar(10) NULL
,  [CoverageGroup] nvarchar(10) NULL
,  [CountGroup] nvarchar(10) NULL
,  [CostGroup] nvarchar(10) NULL
,  [ItemType] nvarchar(10) NULL
,  [ABC] nvarchar(4) NULL
,  [UPCCarton] nvarchar(15) NULL
,  [UPCItem] nvarchar(15) NULL
,  [VitalityDate] date NULL
,  [PCAT] nvarchar(20) NULL
,  [SubPCat] nvarchar(20) NULL
,  [SKUFamily] nvarchar(20) NULL
,  [ShippingClass] nvarchar(30) NULL
,  [Form] nvarchar(20) NULL
,  [Mold] nvarchar(15) NULL
,  [Building] nvarchar(10) NULL
,  [BinLocation] nvarchar(10) NULL
,  [Weight] numeric(28,12) NULL
,  [WeightVariable] numeric(28,12) NULL
,  [WeightFixed] numeric(28,12) NULL
,  [FlushingPrinciple] nvarchar(10) NULL
,  [PrimaryVendor] nvarchar(20) NULL
,  [FreightPerPound] numeric(28,12) NULL
,  [EmbeddedFreightCost] numeric(28,12) NULL
,  [Markup] numeric(28,12) NULL
,  [SalesOrderUnit] nvarchar(10) NULL
,  [SalesPrice] money NULL
,  [SalesDiscount] money NULL
,  [POUnit] nvarchar(10) NULL
,  [POCost] money NULL
,  [InventoryUnit] nvarchar(10) NULL
,  [InventoryCost] money NULL
,  [BOMUnit] nvarchar(10) NULL
,  [IsExplicitFreight] bit NULL
,  [IsPhantom] bit NULL
,  [IsKit] bit NULL
,  [IsLatestPurchasePrice] bit NULL
,  [IsLatestCostPrice] bit NULL
,  [IsStopped] bit NULL
,  [IsCurrent] bit NOT NULL
,  [FromDate] datetime NOT NULL
,  [ToDate] datetime  DEFAULT '12/31/9999' NOT NULL
,  [RowChangeReason] nvarchar(200) NOT NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
, [HashKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat([ItemID], ''))))
, [HashNonKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat(
    IsNull([ItemID], '.')
,   IsNull([ItemName], '.')
,   IsNull([ItemText], '.')
,   IsNull([ItemSearchName], '.')
,   IsNull([LocationKey], -1)
,   IsNull([SubCategoryID], '.')
,   IsNull([SubCategoryName], '.')
,   IsNull([CategoryID], '.')
,   IsNull([CategoryName], '.')
,   IsNull([ProductClassID], '.')
,   IsNull([ProductClassName], '.')
,   IsNull([SalesClassID], '.')
,   IsNull([SalesClassName], '.')
,   IsNull([Purpose], '.')
,   IsNull([BusinessLine], '.')
,   IsNull([ItemGroup], '.')
,   IsNull([FormGroup], '.')
,   IsNull([CommissionGroup], '.')
,   IsNull([DimensionGroup], '.')
,   IsNull([ModelGroup], '.')
,   IsNull([BuyerGroup], '.')
,   IsNull([CoverageGroup], '.')
,   IsNull([CountGroup], '.')
,   IsNull([CostGroup], '.')
,   IsNull([ItemType], '.')
,   IsNull([ItemTier], '.')
,   IsNull([UPCCarton], '.')
,   IsNull([UPCItem], '.')
,   IsNull([VitalityDate], '12/31/1899')
,   IsNull([PCAT], '.')
,   IsNull([PCATSub], '.')
,   IsNull([SKUFamily], '.')
,   IsNull([ShippingClass], '.')
,   IsNull([Form], '.')
,   IsNull([Mold], '.')
,   IsNull([Building], '.')
,   IsNull([BinLocation], '.')
,   IsNull([ProdABCD], '.')
,   IsNull([Scrap], '.')
,   IsNull([Weight], 0.0)
,   IsNull([WeightVariable], 0.0)
,   IsNull([WeightFixed], 0.0)
,   IsNull([ProdFlushing], '.')
,   IsNull([PrimaryVendor], '.')
,   IsNull([FreightPerLb], 0.0)
,   IsNull([ImbFreightCost], 0.0)
,   IsNull([Markup], 0.0)
,   IsNull([UnitConversionRatio], 0.0)
,   IsNull([SOUnit], '.')
,   IsNull([Price], 0.0)
,   IsNull([Discount], 0.0)
,   IsNull([POUnit], '.')
,   IsNull([POCost], 0.0)
,   IsNull([InventoryUnit], '.')
,   IsNull([InventoryCost], 0.0)
,   IsNull([BOMUnit], '.')
,   IsNull([IsExplicitFreight], 0)
,   IsNull([IsPhantom], 0)
,   IsNull([IsKit], 0)
,   IsNull([IsLatestPurchasePrice], 0)
,   IsNull([IsLatestCostPrice], 0)
,   IsNull([IsStopped], 0)
,   IsNull([IsCurrent], 0)
,   IsNull([FromDate], '12/31/1899')
,   IsNull([ToDate], '12/31/1899')
,   IsNull([RowChangeReason], '.')
,   IsNull([InsertAuditKey], -1)
,   IsNull([UpdateAuditKey], -1)
, ''))))
, CONSTRAINT [PK_Stage_DimItem] PRIMARY KEY CLUSTERED 
( [ItemKey] )
) 
;

