/******************************************************
  *
  * Name:         Stage-DimTransaction-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimTransaction]
  *               in the [Stage] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Stage].[DimTransaction] (
   [TransactionKey] int NOT NULL
,  [CostCenter] NVARCHAR(15) NULL
,  [Department] NVARCHAR(15) NULL
,  [Type] NVARCHAR(15) NULL
,  [Purpose] NVARCHAR(15) NULL
,  [BusinessUnit] NVARCHAR(15) NULL
,  [RowChangeReason] NVARCHAR(200) NOT NULL
,  [InsertAuditKey] INT NOT NULL
,  [UpdateAuditKey] INT NOT NULL
, [HashKey] AS (CONVERT([VARBINARY](16), HASHBYTES('MD5', CONCAT([CostCenter], ''))))
, [HashNonKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat(
    IsNull([CostCenter], '.')
,   IsNull([Department], '.')
,   IsNull([Type], '.')
,   IsNull([Purpose], '.')
,   IsNull([BusinessUnit], '.')
,   IsNull([RowChangeReason], '.')
,   IsNull([InsertAuditKey], -1)
,   IsNull([UpdateAuditKey], -1)
, ''))))
, CONSTRAINT [PK_Stage_DimTransaction] PRIMARY KEY CLUSTERED 
( [TransactionKey] )
) 
;

