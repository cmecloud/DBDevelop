/******************************************************
  *
  * Name:         Stage-FactExchangeRate-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [FactExchangeRate]
  *               in the [Stage] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Stage].[FactExchangeRate] (
   [FactExchangeRateKey] int NOT NULL
,  [DateKey] int NULL
,  [SourceCurrencyKey] int NOT NULL
,  [DestinationCurrencyKey] int NOT NULL
,  [ExchangeRate] numeric(9,5) NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
, [HashKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat([DateKey], ''))))
, [HashNonKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat(
    IsNull([DateKey], -1)
,   IsNull([SourceCurrencyKey], -1)
,   IsNull([DestinationCurrencyKey], -1)
,   IsNull([ExchangeRate], 0.0)
,   IsNull([InsertAuditKey], -1)
,   IsNull([UpdateAuditKey], -1)
, ''))))
, CONSTRAINT [PK_Stage_FactExchangeRate] PRIMARY KEY CLUSTERED 
( [FactExchangeRateKey] )
) 
;

