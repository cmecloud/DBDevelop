/******************************************************
  *
  * Name:         Stage-DimLocation-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimLocation]
  *               in the [Stage] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Stage].[DimLocation] (
   [LocationKey] INT NOT NULL
,  [LocationID] NVARCHAR(24) NOT NULL
,  [LocationName] NVARCHAR(60) NOT NULL
,  [SiteID] NVARCHAR(10) NULL
,  [SiteName] NVARCHAR(60) NULL
,  [CompanyKey] INT NOT NULL
,  [IsCurrent] BIT NOT NULL
,  [FromDate] DATETIME NOT NULL
,  [ToDate] DATETIME  DEFAULT '12/31/9999' NOT NULL
,  [RowChangeReason] NVARCHAR(200) NOT NULL
,  [InsertAuditKey] INT NOT NULL
,  [UpdateAuditKey] INT NOT NULL
, [HashKey] AS (CONVERT([VARBINARY](16), HASHBYTES('MD5', CONCAT([LocationID], ''))))
, [HashNonKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat(
    IsNull([LocationID], '.')
,   IsNull([LocationName], '.')
,   IsNull([SiteID], '.')
,   IsNull([SiteName], '.')
,   IsNull([CompanyKey], -1)
,   IsNull([IsCurrent], 0)
,   IsNull([FromDate], '12/31/1899')
,   IsNull([ToDate], '12/31/1899')
,   IsNull([RowChangeReason], '.')
,   IsNull([InsertAuditKey], -1)
,   IsNull([UpdateAuditKey], -1)
, ''))))
, CONSTRAINT [PK_Stage_Location] PRIMARY KEY CLUSTERED 
( [LocationKey] )
) 
;