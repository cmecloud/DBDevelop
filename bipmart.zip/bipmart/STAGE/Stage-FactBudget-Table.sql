/******************************************************
  *
  * Name:         Stage-FactBudget-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [FactBudget]
  *               in the [Stage] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Stage].[FactBudget] (
   [FactBudgetKey] BIGINT NOT NULL
,  [DateKey] INT NOT NULL
,  [CompanyKey] INT NOT NULL
,  [AccountKey] INT NOT NULL
,  [TransactionKey] INT NOT NULL
,  [InsertAuditKey] INT NOT NULL
,  [UpdateAuditKey] INT NOT NULL
,  [ModelNumber] NVARCHAR(10) NULL
,  [BudgetAmount] MONEY NULL
,  [Quantity] NUMERIC(28,12) NULL
, [HashKey] AS (CONVERT([VARBINARY](16), HASHBYTES('MD5', CONCAT([AccountKey], ''))))
, [HashNonKey] AS (CONVERT([VARBINARY](16), HASHBYTES('MD5', CONCAT(
    ISNULL([DateKey], -1)
,   ISNULL([CompanyKey], -1)
,   ISNULL([AccountKey], -1)
,   ISNULL([TransactionKey], -1)
,   ISNULL([InsertAuditKey], -1)
,   ISNULL([UpdateAuditKey], -1)
,   ISNULL([ModelNumber], '.')
,   ISNULL([BudgetAmount], 0.0)
,   ISNULL([Quantity], 0.0)
, ''))))
, CONSTRAINT [PK_Stage_FactBudget] PRIMARY KEY CLUSTERED 
( [FactBudgetKey] )
) 
; 
;

