/******************************************************
  *
  * Name:         Stage-DimLedgerTransaction-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimLedgerTransaction]
  *               in the [Stage] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Stage].[DimLedgerTransaction] (
   [LedgerTransactionKey] int NOT NULL
,  [LedgerTransactionType] INT NULL
,  [LedgerTransactionTypeName] NVARCHAR(30) NULL
,  [LedgerPostingTypeID] INT NULL
,  [LedgerPostingTypeName] NVARCHAR(15) NULL
,  [RowChangeReason] NVARCHAR(200) NOT NULL
,  [InsertAuditKey] INT NOT NULL
,  [UpdateAuditKey] INT NOT NULL
, [HashKey] AS (CONVERT([VARBINARY](16), HASHBYTES('MD5', CONCAT([LedgerTransactionType], ''))))
, [HashNonKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat(
    IsNull([LedgerTransactionType], -1)
,   IsNull([LedgerTransactionTypeName], '.')
,   IsNull([LedgerPostingTypeID], -1)
,   IsNull([LedgerPostingTypeName], '.')
,   IsNull([RowChangeReason], '.')
,   IsNull([InsertAuditKey], -1)
,   IsNull([UpdateAuditKey], -1)
, ''))))
, CONSTRAINT [PK_Stage_DimLedgerTransaction] PRIMARY KEY CLUSTERED 
( [LedgerTransactionKey] )
) 
;

