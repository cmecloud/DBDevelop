/******************************************************
  *
  * Name:         Stage-DimDate-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimDate]
  *               in the [Stage] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Stage].[DimDate] (
   [DateKey] int NOT NULL
,  [DateName] VARCHAR(10) NOT NULL
,  [DateLongName] VARCHAR(50) NOT NULL
,  [FiscalDayNumber] TINYINT NOT NULL
,  [FiscalMonthID] INT NOT NULL
,  [FiscalMonthNumber] TINYINT NOT NULL
,  [FiscalMonthName] VARCHAR(10) NOT NULL
,  [FiscalMonthBegin] DATE NOT NULL
,  [FiscalMonthEnd] DATE NOT NULL
,  [FiscalWeekNumber] TINYINT NOT NULL
,  [FiscalWeekName] VARCHAR(20) NOT NULL
,  [FiscalWeekBegin] DATE NOT NULL
,  [FiscalWeekEnd] DATE NOT NULL
,  [FiscalDayOfWeek] TINYINT NOT NULL
,  [FiscalQuarterID] INT NOT NULL
,  [FiscalQuarterNumber] TINYINT NOT NULL
,  [FiscalQuarterName] VARCHAR(10) NOT NULL
,  [FiscalQuarterBegin] DATETIME NOT NULL
,  [FiscalQuarterEnd] DATETIME NOT NULL
,  [FiscalDayOfQuarter] SMALLINT NOT NULL
,  [FiscalYear] SMALLINT NOT NULL
,  [FiscalYearBegin] DATETIME NOT NULL
,  [FiscalYearEnd] DATETIME NOT NULL
,  [FiscalDayOfYear] SMALLINT NOT NULL
,  [IsCurrent] bit NOT NULL
,  [FromDate] datetime NOT NULL
,  [ToDate] datetime  DEFAULT '12/31/9999' NOT NULL
,  [RowChangeReason] nvarchar(200) NOT NULL
,  [InsertAuditKey] INT NOT NULL
,  [UpdateAuditKey] INT NOT NULL
, [HashKey] AS (CONVERT([VARBINARY](16), HASHBYTES('MD5', CONCAT([DateName], ''))))
, [HashNonKey] AS (CONVERT([VARBINARY](16), HASHBYTES('MD5', CONCAT(
    ISNULL([DateName], '12/31/1899')
,   ISNULL([DateLongName], '12/31/1899')
,   ISNULL([FiscalDayNumber], 0)
,   ISNULL([FiscalMonthID], -1)
,   ISNULL([FiscalMonthNumber], 0)
,   ISNULL([FiscalMonthName], '.')
,   ISNULL([FiscalMonthBegin], '12/31/1899')
,   ISNULL([FiscalMonthEnd], '12/31/1899')
,   ISNULL([FiscalWeekNumber], 0)
,   ISNULL([FiscalWeekName], '.')
,   ISNULL([FiscalWeekBegin], '12/31/1899')
,   ISNULL([FiscalWeekEnd], '12/31/1899')
,   ISNULL([FiscalDayOfWeek], 0)
,   ISNULL([FiscalQuarterID], -1)
,   ISNULL([FiscalQuarterNumber], 0)
,   ISNULL([FiscalQuarterName], '.')
,   ISNULL([FiscalQuarterBegin], '12/31/1899')
,   ISNULL([FiscalQuarterEnd], '12/31/1899')
,   ISNULL([FiscalDayOfQuarter], -1)
,   ISNULL([FiscalYear], -1)
,   ISNULL([FiscalYearBegin], '12/31/1899')
,   ISNULL([FiscalYearEnd], '12/31/1899')
,   ISNULL([FiscalDayOfYear], -1)
,   IsNull([IsCurrent], 0)
,   IsNull([FromDate], '12/31/1899')
,   IsNull([ToDate], '12/31/1899')
,   IsNull([RowChangeReason], '.')
,   ISNULL([InsertAuditKey], -1)
,   ISNULL([UpdateAuditKey], -1)
, ''))))
, CONSTRAINT [PK_Stage_DimDate] PRIMARY KEY CLUSTERED 
( [DateKey] )
) 
;

