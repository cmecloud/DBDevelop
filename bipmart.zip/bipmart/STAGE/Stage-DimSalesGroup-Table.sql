/******************************************************
  *
  * Name:         Stage-DimSalesGroup-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimSalesGroup]
  *               in the [Stage] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Stage].[DimSalesGroup] (
   [SalesGroupKey] INT NOT NULL
,  [SalesGroupID] NVARCHAR(14) NOT NULL
,  [SalesGroupCode] NVARCHAR(10) NULL
,  [SalesGroupName] NVARCHAR(60) NOT NULL
,  [CommissionRate] NUMERIC(8,3) NOT NULL
,  [ItemCommissionGroup] NVARCHAR(20) NULL
,  [IsStopped] BIT NULL
,  [IsCurrent] BIT NOT NULL
,  [FromDate] DATETIME NOT NULL
,  [ToDate] DATETIME  DEFAULT '12/31/9999' NOT NULL
,  [RowChangeReason] NVARCHAR(200) NOT NULL
,  [InsertAuditKey] INT NOT NULL
,  [UpdateAuditKey] INT NOT NULL
, [HashKey] AS (CONVERT([VARBINARY](16), HASHBYTES('MD5', CONCAT([SalesGroupID], ''))))
, [HashNonKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat(
    IsNull([SalesGroupID], '.')
,   IsNull([SalesGroupCode], '.')
,   IsNull([SalesGroupName], '.')
,   IsNull([CommissionRate], 0.0)
,   IsNull([ItemCommissionGroup], '.')
,   IsNull([IsStopped], 0)
,   IsNull([IsCurrent], 0)
,   IsNull([FromDate], '12/31/1899')
,   IsNull([ToDate], '12/31/1899')
,   IsNull([RowChangeReason], '.')
,   IsNull([InsertAuditKey], -1)
,   IsNull([UpdateAuditKey], -1)
, ''))))
, CONSTRAINT [PK_Stage_DimSalesGroup] PRIMARY KEY CLUSTERED 
( [SalesGroupID] )
) 
;

