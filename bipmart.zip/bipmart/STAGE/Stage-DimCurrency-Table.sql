/******************************************************
  *
  * Name:         Stage-DimCurrency-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimCurrency]
  *               in the [Stage] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Stage].[DimCurrency] (
   [CurrencyKey] int NOT NULL
,  [CurrencyID] nvarchar(3) NULL
,  [CurrencyName] nvarchar(20) NULL
,  [IsCurrent] bit NOT NULL
,  [FromDate] datetime NOT NULL
,  [ToDate] datetime  DEFAULT '12/31/9999' NOT NULL
,  [RowChangeReason] nvarchar(200) NOT NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
, [HashKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat([CurrencyID], ''))))
, [HashNonKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat(
    IsNull([CurrencyID], '.')
,   IsNull([CurrencyName], '.')
,   IsNull([IsCurrent], 0)
,   IsNull([FromDate], '12/31/1899')
,   IsNull([ToDate], '12/31/1899')
,   IsNull([RowChangeReason], '.')
,   IsNull([InsertAuditKey], -1)
,   IsNull([UpdateAuditKey], -1)
, ''))))
, CONSTRAINT [PK_Stage_DimCurrency] PRIMARY KEY CLUSTERED 
( [CurrencyKey] )
) 
;
;

