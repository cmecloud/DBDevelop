/******************************************************
  *
  * Name:         Stage-DimCompany-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimCompany]
  *               in the [Stage] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Stage].[DimCompany] (
   [CompanyKey] int NOT NULL
,  [CompanyID] nvarchar(4) NOT NULL
,  [Company] nvarchar(15) NOT NULL
,  [SubRegion] nvarchar(20) NOT NULL
,  [Region] nvarchar(20) NOT NULL
,  [ProductLine] nvarchar(10) NOT NULL
,  [CollectionType] nvarchar(10) NOT NULL
,  [CompanyAddress] int NOT NULL
,  [CurrencyKey] nvarchar(3) NOT NULL
,  [CurrentCompanyKey] nvarchar(4) NULL
,  [IsClosed] bit NOT NULL
,  [IsCurrent] bit NOT NULL
,  [FromDate] datetime NOT NULL
,  [ToDate] datetime  DEFAULT '12/31/9999' NOT NULL
,  [RowChangeReason] nvarchar(200) NOT NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
, [HashKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat([CompanyID], ''))))
, [HashNonKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat(
    IsNull([CompanyID], '.')
,   IsNull([Company], '.')
,   IsNull([SubRegion], '.')
,   IsNull([Region], '.')
,   IsNull([ProductLine], '.')
,   IsNull([CollectionType], '.')
,   IsNull([CompanyAddress], -1)
,   IsNull([CurrencyKey], '.')
,   IsNull([CurrentCompanyKey], '.')
,   IsNull([IsClosed], 0)
,   IsNull([IsCurrent], 0)
,   IsNull([FromDate], '12/31/1899')
,   IsNull([ToDate], '12/31/1899')
,   IsNull([RowChangeReason], '.')
,   IsNull([InsertAuditKey], -1)
,   IsNull([UpdateAuditKey], -1)
, ''))))
, CONSTRAINT [PK_Stage_DimCompany] PRIMARY KEY CLUSTERED 
( [CompanyKey] )
) 
;

