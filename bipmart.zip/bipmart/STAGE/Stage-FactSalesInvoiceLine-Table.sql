/******************************************************
  *
  * Name:         Stage-FactSalesInvoiceLine-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [FactSalesInvoiceLine]
  *               in the [Stage] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Stage].[FactSalesInvoiceLine] (
   [FactSalesInvoiceLineKey] bigint NOT NULL
,  [LocationKey] int NOT NULL
,  [CustomerKey] int NOT NULL
,  [OrderCustomerKey] int NOT NULL
,  [EndCustomerKey] int NOT NULL
,  [ItemKey] int NOT NULL
,  [SalesGroupKey] int NOT NULL
,  [InvoiceDateKey] int NOT NULL
,  [InvoiceDueDateKey] int NOT NULL
,  [DeliveryDateKey] int NOT NULL
,  [CurrencyKey] int NOT NULL
,  [DeliveryAddressKey] int NOT NULL
,  [CompanyKey] int NOT NULL
,  [TransactionKey] int NOT NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
,  [SalesOrderNumber] nvarchar(20) NULL
,  [InvoiceNumber] nvarchar(20) NULL
,  [IsSpecial] bit NULL
,  [IsSpecialInSpecial] bit NULL
,  [DeliveryTerms] nvarchar(10) NULL
,  [DeliveryMode] nvarchar(10) NULL
,  [CommissionGroup] nvarchar(10) NULL
,  [Amount] money NULL
,  [Unit] nvarchar(10) NULL
,  [Quanity] numeric(8,3) NULL
,  [Commission] money NULL
,  [TaxAmount] money NULL
,  [TotalCost] money NULL
,  [UnitPrice] money NULL
,  [UnitCost] money NULL
,  [Discount] money NULL
,  [Freight] money NULL
,  [FreightCost] money NULL
,  [OverheadCostPct] numeric(5,2) NULL
,  [EngineeringHours] numeric(5,2) NULL
,  [LaborHours] numeric(5,2) NULL
, [HashKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat([LocationKey], ''))))
, [HashNonKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat(
    IsNull([LocationKey], -1)
,   IsNull([CustomerKey], -1)
,   IsNull([OrderCustomerKey], -1)
,   IsNull([EndCustomerKey], -1)
,   IsNull([ItemKey], -1)
,   IsNull([SalesGroupKey], -1)
,   IsNull([InvoiceDateKey], -1)
,   IsNull([InvoiceDueDateKey], -1)
,   IsNull([DeliveryDateKey], -1)
,   IsNull([CurrencyKey], -1)
,   IsNull([DeliveryAddressKey], -1)
,   ISNULL([CompanyKey], -1)
,   IsNull([TransactionKey], -1)
,   IsNull([InsertAuditKey], -1)
,   IsNull([UpdateAuditKey], -1)
,   IsNull([SalesOrderNumber], '.')
,   IsNull([InvoiceNumber], '.')
,   IsNull([IsSpecial], 0)
,   IsNull([IsSpecialInSpecial], 0)
,   IsNull([DeliveryTerms], '.')
,   IsNull([DeliveryMode], '.')
,   IsNull([CommissionGroup], '.')
,   IsNull([Amount], 0.0)
,   IsNull([Unit], '.')
,   IsNull([Quanity], 0.0)
,   IsNull([Commission], 0.0)
,   IsNull([TaxAmount], 0.0)
,   IsNull([TotalCost], 0.0)
,   IsNull([UnitPrice], 0.0)
,   IsNull([UnitCost], 0.0)
,   IsNull([Discount], 0.0)
,   IsNull([Freight], 0.0)
,   IsNull([FreightCost], 0.0)
,   IsNull([OverheadCostPct], 0.0)
,   IsNull([EngineeringHours], 0.0)
,   IsNull([LaborHours], 0.0)
, ''))))
, CONSTRAINT [PK_Stage_FactSalesInvoiceLine] PRIMARY KEY CLUSTERED 
( [FactSalesInvoiceLineKey] )
) 
;

