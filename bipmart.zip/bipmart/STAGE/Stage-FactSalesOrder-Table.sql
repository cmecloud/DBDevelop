/******************************************************
  *
  * Name:         Stage-FactSalesOrder-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [FactSalesOrder]
  *               in the [Stage] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Stage].[FactSalesOrder] (
   [FactSalesOrderKey] bigint IDENTITY NOT NULL
,  [LocationKey] int NOT NULL
,  [CustomerKey] int NOT NULL
,  [EndCustomerKey] int NULL
,  [ItemKey] int NOT NULL
,  [SalesGroupKey] int NOT NULL
,  [OrderDateKey] int NOT NULL
,  [DeliveryDateKey] int NOT NULL
,  [PromiseDateKey] int NOT NULL
,  [CurrencyKey] int NOT NULL
,  [TransactionKey] int NOT NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
,  [SalesOrderNumber] nvarchar(20) NULL
,  [SalesLineNumber] nvarchar(20) NULL
,  [IsSpecial] bit NOT NULL
,  [IsSpecialInSpecial] bit NULL
,  [IsOnHold] bit NOT NULL
,  [SalesUnit] nvarchar(10) NULL
,  [SalesAmount] money NULL
,  [QuantitySold] numeric(8,3) NULL
,  [QuantityOrdered] numeric(8,3) NULL
,  [UnitPrice] money NULL
,  [UnitCost] money NULL
,  [Discount] money NULL
,  [Freight] money NULL
,  [FreightCost] money NULL
,  [OverheadCostPct] numeric(5,2) NULL
,  [EngineeringHours] numeric(5,2) NULL
,  [LaborHours] numeric(5,2) NULL
, [HashKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat([FactSalesOrderKey], ''))))
, [HashNonKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat(
    IsNull([LocationKey], -1)
,   IsNull([CustomerKey], -1)
,   IsNull([EndCustomerKey], -1)
,   IsNull([ItemKey], -1)
,   IsNull([SalesGroupKey], -1)
,   IsNull([OrderDateKey], -1)
,   IsNull([DeliveryDateKey], -1)
,   IsNull([PromiseDateKey], -1)
,   IsNull([CurrencyKey], -1)
,   IsNull([TransactionKey], -1)
,   IsNull([InsertAuditKey], -1)
,   IsNull([UpdateAuditKey], -1)
,   IsNull([SalesOrderNumber], '.')
,   IsNull([SalesLineNumber], '.')
,   IsNull([IsSpecial], 0)
,   IsNull([IsSpecialInSpecial], 0)
,   IsNull([IsOnHold], 0)
,   IsNull([SalesUnit], '.')
,   IsNull([SalesAmount], 0.0)
,   IsNull([QuantitySold], 0.0)
,   IsNull([QuantityOrdered], 0.0)
,   IsNull([UnitPrice], 0.0)
,   IsNull([UnitCost], 0.0)
,   IsNull([Discount], 0.0)
,   IsNull([Freight], 0.0)
,   IsNull([FreightCost], 0.0)
,   IsNull([OverheadCostPct], 0.0)
,   IsNull([EngineeringHours], 0.0)
,   IsNull([LaborHours], 0.0)
, ''))))
, CONSTRAINT [PK_Stage_FactSalesOrder] PRIMARY KEY NONCLUSTERED 
( [FactSalesOrderKey] )
) 
;

