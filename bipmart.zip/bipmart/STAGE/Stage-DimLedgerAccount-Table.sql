/******************************************************
  *
  * Name:         Stage-DimLedgerAccount-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimLedgerAccount]
  *               in the [Stage] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Stage].[DimLedgerAccount] (
   [AccountKey] int NOT NULL
,  [AccountID] nvarchar(20) NULL
,  [AccountNumber] nvarchar(20) NULL
,  [AccountName] nvarchar(60) NULL
,  [AccountGroup] nvarchar(60) NULL
,  [AccountType] nvarchar(20) NULL
,  [ParentAccountID] nvarchar(20) NULL
,  [CompanyKey] int NULL
,  [AggregationBehavior] tinyint NULL
,  [AggregationOperator] nvarchar(10) NULL
,  [Unit] nvarchar(10) NULL
,  [IsExcludedDPO] bit NULL
,  [IsMovementAllowed] bit NULL
,  [IsLocked] bit NULL
,  [IsClosed] bit NULL
,  [IsSales] bit NULL
,  [IsNewOrders] bit NULL
,  [IsBacklog] bit NULL
,  [IsOverhead] bit NULL
,  [IsCurrent] bit NOT NULL
,  [FromDate] datetime NOT NULL
,  [ToDate] datetime  DEFAULT '12/31/9999' NOT NULL
,  [RowChangeReason] nvarchar(200) NOT NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
, [HashKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat([AccountID], ''))))
, [HashNonKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat(
    IsNull([AccountID], '.')
,   IsNull([AccountNumber], '.')
,   IsNull([AccountName], '.')
,   IsNull([AccountGroup], '.')
,   IsNull([AccountType], '.')
,   IsNull([ParentAccountID], '.')
,   IsNull([CompanyKey], -1)
,   IsNull([AggregationBehavior], 0)
,   IsNull([AggregationOperator], '.')
,   IsNull([Unit], '.')
,   IsNull([IsExcludedDPO], 0)
,   IsNull([IsMovementAllowed], 0)
,   IsNull([IsLocked], 0)
,   IsNull([IsClosed], 0)
,   IsNull([IsSales], 0)
,   IsNull([IsNewOrders], 0)
,   IsNull([IsBacklog], 0)
,   IsNull([IsOverhead], 0)
,   IsNull([IsCurrent], 0)
,   IsNull([FromDate], '12/31/1899')
,   IsNull([ToDate], '12/31/1899')
,   IsNull([RowChangeReason], '.')
,   IsNull([InsertAuditKey], -1)
,   IsNull([UpdateAuditKey], -1)
, ''))))
, CONSTRAINT [PK_Stage_DimLedgerAccount] PRIMARY KEY CLUSTERED 
( [AccountKey] )
) 
;

