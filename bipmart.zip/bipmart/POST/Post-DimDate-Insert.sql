/******************************************************
  *
  * Name:         Post-DimDate-Insert.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Insert default record into [DimDate]   
  *               table in [Stage] schema.
  *
  *               Call merge stored procedure to migrate
  *               to table in [Mart] schema.
  * 
  ******************************************************/
---  Refresh
DELETE FROM [Mart].[DimDate] WHERE DateKey = -1
BEGIN

 -- Set on
 SET IDENTITY_INSERT [Stage].[DimDate] ON;
 GO
 
 -- Common Table Expression
 ;
 WITH CTE_DATA
 (
             DateKey, 
            DateName, 
            DateLongName, 
            FiscalDayNumber, 
            FiscalMonthID, 
            FiscalMonthNumber, 
            FiscalMonthName, 
            FiscalMonthBegin, 
            FiscalMonthEnd, 
            FiscalWeekNumber, 
            FiscalWeekName, 
            FiscalWeekBegin, 
            FiscalWeekEnd, 
            FiscalDayOfWeek, 
            FiscalQuarterID, 
            FiscalQuarterNumber, 
            FiscalQuarterName, 
            FiscalQuarterBegin, 
            FiscalQuarterEnd, 
            FiscalDayOfQuarter, 
            FiscalYear, 
            FiscalYearBegin, 
            FiscalYearEnd, 
            FiscalDayOfYear, 
            CalendarDayNumber, 
            CalendarMonthID, 
            CalendarMonthNumber, 
            CalendarMonthName, 
            CalenderMonthBegin, 
            CalendarMonthEnd, 
            CalendarQuarterID, 
            CalendarQuarterNumber, 
            CalendarQuarterName, 
            CalendarQuarterBegin, 
            CalendarQuarterEnd, 
            CalendarYear, 
            CalendarYearBegin, 
            CalendarYearEnd, 
            CalendarQuarterDaysSinceStart, 
            CalendarYearDaysSinceStart, 
            InsertAuditKey, 
            UpdateAuditKey

 )
 AS
 (
   SELECT 
             -1, 
            '12/31/1899', 
            '12/31/1899', 
            0, 
            -1, 
            0, 
            'U', 
            '12/31/1899', 
            '12/31/1899', 
            0, 
            'U', 
            '12/31/1899', 
            '12/31/1899', 
            0, 
            -1, 
            0, 
            'U', 
            '12/31/1899', 
            '12/31/1899', 
            -1, 
            -1, 
            '12/31/1899', 
            '12/31/1899', 
            -1, 
            0, 
            -1, 
            0, 
            'U', 
            '12/31/1899', 
            '12/31/1899', 
            -1, 
            0, 
            'U', 
            '12/31/1899', 
            '12/31/1899', 
            -1, 
            '12/31/1899', 
            '12/31/1899', 
            -1, 
            -1, 
            -1, 
            -1

 )
 
 INSERT INTO [Stage].[DimDate] 
 (
             DateKey, 
            DateName, 
            DateLongName, 
            FiscalDayNumber, 
            FiscalMonthID, 
            FiscalMonthNumber, 
            FiscalMonthName, 
            FiscalMonthBegin, 
            FiscalMonthEnd, 
            FiscalWeekNumber, 
            FiscalWeekName, 
            FiscalWeekBegin, 
            FiscalWeekEnd, 
            FiscalDayOfWeek, 
            FiscalQuarterID, 
            FiscalQuarterNumber, 
            FiscalQuarterName, 
            FiscalQuarterBegin, 
            FiscalQuarterEnd, 
            FiscalDayOfQuarter, 
            FiscalYear, 
            FiscalYearBegin, 
            FiscalYearEnd, 
            FiscalDayOfYear, 
            CalendarDayNumber, 
            CalendarMonthID, 
            CalendarMonthNumber, 
            CalendarMonthName, 
            CalenderMonthBegin, 
            CalendarMonthEnd, 
            CalendarQuarterID, 
            CalendarQuarterNumber, 
            CalendarQuarterName, 
            CalendarQuarterBegin, 
            CalendarQuarterEnd, 
            CalendarYear, 
            CalendarYearBegin, 
            CalendarYearEnd, 
            CalendarQuarterDaysSinceStart, 
            CalendarYearDaysSinceStart, 
            InsertAuditKey, 
            UpdateAuditKey

 )
 SELECT * FROM CTE_DATA
 GO
 
 -- Set off
 SET IDENTITY_INSERT [Stage].[DimDate] OFF
 GO
 
 -- Execute a merge
 Exec [Mart].[MergeDimDate]
 GO
