/******************************************************
  *
  * Name:         Post-DimSalesGroup-Insert.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Insert default record into [DimSalesGroup]   
  *               table in [Stage] schema.
  *
  *               Call merge stored procedure to migrate
  *               to table in [Mart] schema.
  * 
  ******************************************************/
---Refresh  
DELETE FROM [Mart].[DimSalesGroup] WHERE SalesGroupKey = -1
BEGIN

 -- Set on
 SET IDENTITY_INSERT [Stage].[DimSalesGroup] ON;
 GO
 
 -- Common Table Expression
 ;
 WITH CTE_DATA
 (
            SalesGroupKey, 
            SalesGroupID, 
            SalesGroupCode, 
            SalesGroupName, 
            CommissionRate, 
            ItemCommissionGroup, 
            IsStopped, 
            IsCurrent, 
            FromDate, 
            ToDate, 
            RowChangeReason, 
            InsertAuditKey, 
            UpdateAuditKey

 )
 AS
 (
   SELECT 
             -1, 
            'U', 
            'U', 
            'U', 
            0.0, 
            'U', 
            0, 
            0, 
            '12/31/1899', 
            '12/31/1899', 
            'U', 
            -1, 
            -1

 )
 
 INSERT INTO [Stage].[DimSalesGroup] 
 (
             SalesGroupKey, 
            SalesGroupID, 
            SalesGroupCode, 
            SalesGroupName, 
            CommissionRate, 
            ItemCommissionGroup, 
            IsStopped, 
            IsCurrent, 
            FromDate, 
            ToDate, 
            RowChangeReason, 
            InsertAuditKey, 
            UpdateAuditKey

 )
 SELECT * FROM CTE_DATA
 GO
 
 -- Set off
 SET IDENTITY_INSERT [Stage].[DimSalesGroup] OFF
 GO
 
 -- Execute a merge
 Exec [Mart].[MergeDimSalesGroup]
 GO
