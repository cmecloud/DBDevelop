/******************************************************
  *
  * Name:         Post-DimLedgerAccount-Insert.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Insert default record into [DimLedgerAccount]   
  *               table in [Stage] schema.
  *
  *               Call merge stored procedure to migrate
  *               to table in [Mart] schema.
  * 
  ******************************************************/

---  Refresh
DELETE FROM [Mart].[DimLedgerAccount] WHERE AccountKey = -1
BEGIN

 -- Set on
 SET IDENTITY_INSERT [Stage].[DimLedgerAccount] ON;
 GO
 
 -- Common Table Expression
 ;
 WITH CTE_DATA
 (
             AccountKey, 
            AccountID, 
            AccountNumber, 
            AccountName, 
            AccountGroup, 
            AccountType, 
            ParentAccountID, 
            CompanyKey, 
            AggregationBehavior, 
            AggregationOperator, 
            Unit, 
            IsExcludedDPO, 
            IsMovementAllowed, 
            IsLocked, 
            IsClosed, 
            IsSales, 
            IsNewOrders, 
            IsBacklog, 
            IsOverhead, 
            IsCurrent, 
            FromDate, 
            ToDate, 
            RowChangeReason, 
            InsertAuditKey, 
            UpdateAuditKey

 )
 AS
 (
   SELECT 
             -1, 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            -1, 
            0, 
            'U', 
            'U', 
            0, 
            0, 
            0, 
            0, 
            0, 
            0, 
            0, 
            0, 
            0, 
            '12/31/1899', 
            '12/31/1899', 
            'U', 
            -1, 
            -1

 )
 
 INSERT INTO [Stage].[DimLedgerAccount] 
 (
             AccountKey, 
            AccountID, 
            AccountNumber, 
            AccountName, 
            AccountGroup, 
            AccountType, 
            ParentAccountID, 
            CompanyKey, 
            AggregationBehavior, 
            AggregationOperator, 
            Unit, 
            IsExcludedDPO, 
            IsMovementAllowed, 
            IsLocked, 
            IsClosed, 
            IsSales, 
            IsNewOrders, 
            IsBacklog, 
            IsOverhead, 
            IsCurrent, 
            FromDate, 
            ToDate, 
            RowChangeReason, 
            InsertAuditKey, 
            UpdateAuditKey

 )
 SELECT * FROM CTE_DATA
 GO
 
 -- Set off
 SET IDENTITY_INSERT [Stage].[DimLedgerAccount] OFF
 GO
 
 -- Execute a merge
 Exec [Mart].[MergeDimLedgerAccount]
 GO
