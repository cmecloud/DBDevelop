/******************************************************
  *
  * Name:         Post-DimAudit-Insert.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Insert default record into [DimAudit]   
  *               table in [Mart] schema.
  *
  *               Removed - Call merge stored procedure to migrate
  *               to table in [Mart] schema.
  * 
  ******************************************************/

---  Refresh
DELETE FROM [Mart].[DimAudit] WHERE AuditKey = -1
BEGIN

 -- Set on
 SET IDENTITY_INSERT [Mart].[DimAudit] ON;
 GO
 
 -- Common Table Expression
 ;
 WITH CTE_DATA
 (
             AuditKey, 
            LoadDate, 
            SourceFileName

 )
 AS
 (
   SELECT 
             -1, 
            '12/31/1899', 
            'U'

 )
 
 INSERT INTO [Mart].[DimAudit] 
 (
             AuditKey, 
            LoadDate, 
            SourceFileName

 )
 SELECT * FROM CTE_DATA
 GO
 
 -- Set off
 SET IDENTITY_INSERT [Mart].[DimAudit] OFF
 GO

