/******************************************************
  *
  * Name:         Post-DimItem-Insert.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Insert default record into [DimItem]   
  *               table in [Stage] schema.
  *
  *               Call merge stored procedure to migrate
  *               to table in [Mart] schema.
  * 
  ******************************************************/
---  Refresh
DELETE FROM [Mart].[DimItem] WHERE ItemKey = -1
BEGIN

--- Set on
 SET IDENTITY_INSERT [Stage].[DimItem] ON;
 GO
 
 -- Common Table Expression
 ;
 WITH CTE_DATA
 (
            ItemKey, 
            ItemID, 
            ItemName, 
            ItemText, 
            ItemSearchName, 
            LocationKey, 
            SubCategoryID, 
            SubCategory, 
            CategoryID, 
            Category, 
            ProductClassID, 
            ProductClassName, 
            SalesClassID, 
            SalesClass, 
            PurposeKey, 
            BusinessLineKey, 
            ItemGroup, 
            FormGroup, 
            CommissionGroup, 
            DimensionGroup, 
            ModelGroup, 
            BuyerGroup, 
            CoverageGroup, 
            CountGroup, 
            CostGroup, 
            ItemType, 
            ItemTier, 
            UPCCarton, 
            UPCItem, 
            VitalityDate, 
            PCAT, 
            PCATSub, 
            SKUFamily, 
            ShippingClass, 
            Form, 
            Mold, 
            Building, 
            BinLocation, 
            ProdABCD, 
            Scrap, 
            Weight, 
            WeightVariable, 
            WeightFixed, 
            ProdFlushing, 
            PrimaryVendor, 
            FreightPerLb, 
            ImbFreightCost, 
            Markup, 
            UnitConversionRatio, 
            SOUnit, 
            Price, 
            Discount, 
            POUnit, 
            POCost, 
            InventoryUnit, 
            InventoryCost, 
            BOMUnit, 
            IsExplicitFreight, 
            IsPhantom, 
            IsKit, 
            IsLatestPurchasePrice, 
            IsLatestCostPrice, 
            IsStopped, 
            IsCurrent, 
            FromDate, 
            ToDate, 
            RowChangeReason, 
            InsertAuditKey, 
            UpdateAuditKey

 )
 AS
 (
   SELECT 
             -1, 
            'U', 
            'U', 
            'U', 
            'U', 
            -1, 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            '12/31/1899', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            0.0, 
            0.0, 
            0.0, 
            'U', 
            'U', 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            'U', 
            0.0, 
            0.0, 
            'U', 
            0.0, 
            'U', 
			0.0,
            0.0, 
            'U', 
            0, 
            0, 
            0, 
            0, 
            0, 
            0, 
            0, 
            '12/31/1899', 
            '12/31/1899', 
            'U', 
            -1, 
            -1

 )
 
 INSERT INTO [Stage].[DimItem] 
 (
             ItemKey, 
            ItemID, 
            ItemName, 
            ItemText, 
            ItemSearchName, 
            LocationKey, 
            SubCategoryID, 
            SubCategoryName, 
            CategoryID, 
            CategoryName, 
            ProductClassID, 
            ProductClassName, 
            SalesClassID, 
            SalesClassName, 
            Purpose, 
            BusinessLine, 
            ItemGroup, 
            FormGroup, 
            CommissionGroup, 
            DimensionGroup, 
            ModelGroup, 
            BuyerGroup, 
            CoverageGroup, 
            CountGroup, 
            CostGroup, 
            ItemType, 
            ItemTier, 
            UPCCarton, 
            UPCItem, 
            VitalityDate, 
            PCAT, 
            PCATSub, 
            SKUFamily, 
            ShippingClass, 
            Form, 
            Mold, 
            Building, 
            BinLocation, 
            ProdABCD, 
            Scrap, 
            Weight, 
            WeightVariable, 
            WeightFixed, 
            ProdFlushing, 
            PrimaryVendor, 
            FreightPerLb, 
            ImbFreightCost, 
            Markup, 
            UnitConversionRatio, 
            SOUnit, 
            Price, 
            Discount, 
            POUnit, 
            POCost, 
            InventoryUnit, 
            InventoryCost, 
            BOMUnit, 
            IsExplicitFreight, 
            IsPhantom, 
            IsKit, 
            IsLatestPurchasePrice, 
            IsLatestCostPrice, 
            IsStopped, 
            IsCurrent, 
            FromDate, 
            ToDate, 
            RowChangeReason, 
            InsertAuditKey, 
            UpdateAuditKey

 )
 SELECT * FROM CTE_DATA
 GO
 
 -- Set off
 SET IDENTITY_INSERT [Stage].[DimItem] OFF
 GO
 
 -- Execute a merge
 Exec [Mart].[MergeDimItem]
 GO
