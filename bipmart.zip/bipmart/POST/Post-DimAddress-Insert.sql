/******************************************************
  *
  * Name:         Post-DimAddress-Insert.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Insert default record into [DimAddress]   
  *               table in [Stage] schema.
  *
  *               Call merge stored procedure to migrate
  *               to table in [Mart] schema.
  * 
  ******************************************************/

-- Only insert default record if destination table is empty.
--IF NOT EXISTS (SELECT TOP 1 FROM [Mart].[DimAddress])

---Refresh
DELETE FROM [Mart].[DimAddress] WHERE AddressKey = -1
BEGIN

	 -- Set on
	 SET IDENTITY_INSERT [Stage].[DimAddress] ON;
 
	 -- Common Table Expression
	 ;
	 WITH CTE_DATA
	 (
				 AddressKey, 
				AddressID, 
				AddressLine1, 
				Street, 
				CountryID, 
				CountryName, 
				StateProvinceID, 
				StateProvinceName, 
				CityName, 
				CountyName, 
				ZipCode, 
				IsCurrent, 
				FromDate, 
				ToDate, 
				RowChangeReason, 
				InsertAuditKey, 
				UpdateAuditKey

	 )
	 AS
	 (
	   SELECT 
				 -1, 
				'U', 
				'U', 
				'U', 
				'U', 
				'U', 
				'U', 
				'U', 
				'U', 
				'U', 
				'U', 
				0, 
				'12/31/1899', 
				'12/31/1899', 
				'U', 
				-1, 
				-1

	 )
 
	 INSERT INTO [Stage].[DimAddress] 
	 (
				 AddressKey, 
				AddressID, 
				AddressLine1, 
				Street, 
				CountryID, 
				CountryName, 
				StateProvinceID, 
				StateProvinceName, 
				CityName, 
				CountyName, 
				ZipCode, 
				IsCurrent, 
				FromDate, 
				ToDate, 
				RowChangeReason, 
				InsertAuditKey, 
				UpdateAuditKey

	 )
	 SELECT * FROM CTE_DATA
 
	 -- Set off
	 SET IDENTITY_INSERT [Stage].[DimAddress] OFF
 
	 -- Execute a merge
	 Exec [Mart].[MergeDimAddress]

END