/******************************************************
  *
  * Name:         Post-FactBudget-Insert.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Insert default record into [FactBudget]   
  *               table in [Stage] schema.
  *
  *               Call merge stored procedure to migrate
  *               to table in [Mart] schema.
  * 
  ******************************************************/

--- Refresh Table
DELETE FROM [Mart].[DimFactBudget] WHERE FactBudgetKey = -1
BEGIN

 -- Set on
 SET IDENTITY_INSERT [Stage].[FactBudget] ON;
 GO
 
 -- Common Table Expression
 ;
 WITH CTE_DATA
 (
             FactBudgetKey, 
            DateKey, 
            CompanyKey, 
            AccountKey, 
            TransactionKey, 
            InsertAuditKey, 
            UpdateAuditKey, 
            ModelNumber, 
            BudgetAmount, 
            Quantity

 )
 AS
 (
   SELECT 
             -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            'U', 
            0.0, 
            0.0

 )
 
 INSERT INTO [Stage].[FactBudget] 
 (
             FactBudgetKey, 
            DateKey, 
            CompanyKey, 
            AccountKey, 
            TransactionKey, 
            InsertAuditKey, 
            UpdateAuditKey, 
            ModelNumber, 
            BudgetAmount, 
            Quantity

 )
 SELECT * FROM CTE_DATA
 GO
 
 -- Set off
 SET IDENTITY_INSERT [Stage].[FactBudget] OFF
 GO
 
 -- Execute a merge
 Exec [Mart].[MergeFactBudget]
 GO
