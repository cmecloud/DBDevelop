/******************************************************
  *
  * Name:         Post-DimCurrency-Insert.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Insert default record into [DimCurrency]   
  *               table in [Stage] schema.
  *
  *               Call merge stored procedure to migrate
  *               to table in [Mart] schema.
  * 
  ******************************************************/
  ---  Refresh
DELETE FROM [Mart].[DimCurrency] WHERE CurrencyKey = -1
BEGIN

 -- Set on
 SET IDENTITY_INSERT [Stage].[DimCurrency] ON;
 GO
 
 -- Common Table Expression
 ;
 WITH CTE_DATA
 (
             CurrencyKey, 
            CurrencyID, 
            CurrencyName, 
            IsCurrent, 
            FromDate, 
            ToDate, 
            RowChangeReason, 
            InsertAuditKey, 
            UpdateAuditKey

 )
 AS
 (
   SELECT 
             -1, 
            'U', 
            'U', 
            0, 
            '12/31/1899', 
            '12/31/1899', 
            'U', 
            -1, 
            -1

 )
 
 INSERT INTO [Stage].[DimCurrency] 
 (
             CurrencyKey, 
            CurrencyID, 
            CurrencyName, 
            IsCurrent, 
            FromDate, 
            ToDate, 
            RowChangeReason, 
            InsertAuditKey, 
            UpdateAuditKey

 )
 SELECT * FROM CTE_DATA
 GO
 
 -- Set off
 SET IDENTITY_INSERT [Stage].[DimCurrency] OFF
 GO
 
 -- Execute a merge
 Exec [Mart].[MergeDimCurrency]
 GO
