/******************************************************
  *
  * Name:         Post-DimCompany-Insert.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Insert default record into [DimCompany]   
  *               table in [Stage] schema.
  *
  *               Call merge stored procedure to migrate
  *               to table in [Mart] schema.
  * 
  ******************************************************/
  ---  Refresh
DELETE FROM [Mart].[DimCompany] WHERE CompanyKey = -1
BEGIN

 -- Set on
 SET IDENTITY_INSERT [Stage].[DimCompany] ON;
 GO
 
 -- Common Table Expression
 ;
 WITH CTE_DATA
 (
            CompanyKey, 
            CompanyID, 
            Company, 
            SubRegion, 
            Region, 
            ProductLine, 
            CollectionType, 
            CompanyAddress, 
            CurrencyKey, 
            CurrentCompanyKey, 
            IsClosed, 
            IsCurrent, 
            FromDate, 
            ToDate, 
            RowChangeReason, 
            InsertAuditKey, 
            UpdateAuditKey

 )
 AS
 (
   SELECT 
             -1, 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            -1, 
            'U', 
            'U', 
            0, 
            0, 
            '12/31/1899', 
            '12/31/1899', 
            'U', 
            -1, 
            -1

 )
 
 INSERT INTO [Stage].[DimCompany] 
 (
            CompanyKey, 
            CompanyID, 
            Company, 
            SubRegion, 
            Region, 
            ProductLine, 
            CollectionType, 
            CompanyAddress, 
            CurrencyKey, 
            CurrentCompanyKey, 
            IsClosed, 
            IsCurrent, 
            FromDate, 
            ToDate, 
            RowChangeReason, 
            InsertAuditKey, 
            UpdateAuditKey

 )
 SELECT * FROM CTE_DATA
 GO
 
 -- Set off
 SET IDENTITY_INSERT [Stage].[DimCompany] OFF
 GO
 
 -- Execute a merge
 Exec [Mart].[MergeDimCompany]
 GO
