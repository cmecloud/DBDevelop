/******************************************************
  *
  * Name:         Post-FactSalesInvoice-Insert.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Insert default record into [FactSalesInvoice]   
  *               table in [Stage] schema.
  *
  *               Call merge stored procedure to migrate
  *               to table in [Mart] schema.
  * 
  ******************************************************/

 -- Set on
 SET IDENTITY_INSERT [Stage].[FactSalesInvoice] ON;
 GO
 
 -- Common Table Expression
 ;
 WITH CTE_DATA
 (
             FactSalesInvoiceKey, 
            LocationKey, 
            CustomerKey, 
            OrderCustomerKey, 
            EndCustomerKey, 
            ItemKey, 
            SalesGroupKey, 
            InvoiceDateKey, 
            InvoiceDueDateKey, 
            DeliveryDateKey, 
            CurrencyKey, 
            DeliveryAddressKey, 
            TransactionKey, 
            InsertAuditKey, 
            UpdateAuditKey, 
            SalesOrderNumber, 
            InvoiceNumber, 
            IsSpecial, 
            IsSpecialInSpecial, 
            DeliveryTerms, 
            DeliveryMode, 
            CommissionGroup, 
            Amount, 
            Unit, 
            Quanity, 
            Commission, 
            TaxAmount, 
            TotalCost, 
            UnitPrice, 
            UnitCost, 
            Discount, 
            Freight, 
            FreightCost, 
            OverheadCostPct, 
            EngineeringHours, 
            LaborHours

 )
 AS
 (
   SELECT 
             -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            'U', 
            'U', 
            0, 
            0, 
            'U', 
            'U', 
            'U', 
            0.0, 
            'U', 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0

 )
 
 INSERT INTO [Stage].[FactSalesInvoice] 
 (
             FactSalesInvoiceKey, 
            LocationKey, 
            CustomerKey, 
            OrderCustomerKey, 
            EndCustomerKey, 
            ItemKey, 
            SalesGroupKey, 
            InvoiceDateKey, 
            InvoiceDueDateKey, 
            DeliveryDateKey, 
            CurrencyKey, 
            DeliveryAddressKey, 
            TransactionKey, 
            InsertAuditKey, 
            UpdateAuditKey, 
            SalesOrderNumber, 
            InvoiceNumber, 
            IsSpecial, 
            IsSpecialInSpecial, 
            DeliveryTerms, 
            DeliveryMode, 
            CommissionGroup, 
            Amount, 
            Unit, 
            Quanity, 
            Commission, 
            TaxAmount, 
            TotalCost, 
            UnitPrice, 
            UnitCost, 
            Discount, 
            Freight, 
            FreightCost, 
            OverheadCostPct, 
            EngineeringHours, 
            LaborHours

 )
 SELECT * FROM CTE_DATA
 GO
 
 -- Set off
 SET IDENTITY_INSERT [Stage].[FactSalesInvoice] OFF
 GO
 
 -- Execute a merge
 Exec [Mart].[MergeFactSalesInvoice]
 GO
