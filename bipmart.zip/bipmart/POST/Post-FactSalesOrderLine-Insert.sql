/******************************************************
  *
  * Name:         Post-FactSalesOrderLine-Insert.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Insert default record into [FactSalesOrderLine]   
  *               table in [Stage] schema.
  *
  *               Call merge stored procedure to migrate
  *               to table in [Mart] schema.
  * 
  ******************************************************/
 --Refresh
DELETE FROM [Mart].[FActSalesOrderLine] WHERE FactSalesOrderLineKey = -1
BEGIN

 
 -- Set on

 SET IDENTITY_INSERT [Stage].[FactSalesOrderLine] ON;
 GO
 
 -- Common Table Expression
 ;
 WITH CTE_DATA
 (
            FactSalesOrderLineKey, 
            LocationKey, 
            CustomerKey, 
            EndCustomerKey, 
            ItemKey, 
            SalesGroupKey, 
            OrderDateKey, 
            DeliveryDateKey, 
            PromiseDateKey, 
            CurrencyKey, 
			CompanyKey,
            TransactionKey, 
            InsertAuditKey, 
            UpdateAuditKey, 
            SalesOrderNumber, 
            SalesLineNumber, 
            IsSpecial, 
            IsSpecialInSpecial, 
            IsOnHold, 
            SalesUnit, 
            SalesAmount, 
            QuantitySold, 
            QuantityOrdered, 
            UnitPrice, 
            UnitCost, 
            Discount, 
            Freight, 
            FreightCost, 
            OverheadCostPct, 
            EngineeringHours, 
            LaborHours

 )
 AS
 (
   SELECT 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
			-1,
            -1, 
			-1,
            -1, 
            -1, 
            'U', 
            'U', 
            0, 
            0, 
            0, 
            'U', 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0

 )
 
 INSERT INTO [Stage].[FactSalesOrderLine] 
 (
            FactSalesOrderLineKey, 
            LocationKey, 
            CustomerKey, 
            EndCustomerKey, 
            ItemKey, 
            SalesGroupKey, 
            OrderDateKey, 
            DeliveryDateKey, 
            PromiseDateKey, 
            CurrencyKey, 
			CompanyKey,
            TransactionKey, 
            InsertAuditKey, 
            UpdateAuditKey, 
            SalesOrderNumber, 
            SalesLineNumber, 
            IsSpecial, 
            IsSpecialInSpecial, 
            IsOnHold, 
            SalesUnit, 
            SalesAmount, 
            QuantitySold, 
            QuantityOrdered, 
            UnitPrice, 
            UnitCost, 
            Discount, 
            Freight, 
            FreightCost, 
            OverheadCostPct, 
            EngineeringHours, 
            LaborHours

 )
 SELECT * FROM CTE_DATA
 GO
 
 -- Set off
 SET IDENTITY_INSERT [Stage].[FactSalesOrderLine] OFF
 GO
 
 -- Execute a merge
 EXECUTE [Mart].[MergeFactSalesOrderLine]
 GO