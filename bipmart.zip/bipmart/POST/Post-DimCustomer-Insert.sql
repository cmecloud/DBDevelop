/******************************************************
  *
  * Name:         Post-DimCustomer-Insert.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Insert default record into [DimCustomer]   
  *               table in [Stage] schema.
  *
  *               Call merge stored procedure to migrate
  *               to table in [Mart] schema.
  * 
  ******************************************************/

---  Refresh
DELETE FROM [Mart].[DimCustomer] WHERE CustomerKey = -1
BEGIN

 -- Set on
 SET IDENTITY_INSERT [Stage].[DimCustomer] ON;
 GO
 
 -- Common Table Expression
 ;
 WITH CTE_DATA
 (
            CustomerKey, 
            CustomerID, 
            Customer, 
            CustomerLongName, 
            CustomerSearchName, 
            CompanyKey, 
            CommonCustomerKey, 
            ShipToAddressKey, 
            BillToAddressKey, 
            CurrencyKey, 
            SalesGroupKey, 
            CustomerCode, 
            CustomerCodeName, 
            CommonCustomerID, 
            CommonCustomerName, 
            CustomerCategoryID, 
            CustomerCategoryName, 
            CustomerGroup, 
            PhoneNumber, 
            FaxNumber, 
            CellNumber, 
            ContactName, 
            ContactPhone, 
            ContactEmail, 
            MainContact, 
            DateOpened, 
            BusinessLine, 
            AccountType, 
            Purpose, 
            Segment, 
            Language, 
            RegionalSalesManager, 
            CommissionGroup, 
            PriceGroup, 
            ItemGroup, 
            CollectorCode, 
            TaxGroup, 
            TaxResaleNumber, 
            TaxExpiration, 
            PaymentTermID, 
            PaymentTermName, 
            Discount, 
            LineDiscount, 
            CreditLimit, 
            CreditManager, 
            CreditRating, 
            CreditRiskType, 
            CreditBin, 
            CreditParentBin, 
            CustomerParent, 
            RebateCode, 
            Rebate, 
            MethodOfPayment, 
            Stopped, 
            AccountStatement, 
            Flag, 
            SpecialInstructions, 
            ExcludeFromInterest, 
            PrintInvoice, 
            IsNational, 
            IsArchived, 
            IsCurrent, 
            FromDate, 
            ToDate, 
            RowChangeReason, 
            InsertAuditKey, 
            UpdateAuditKey

 )
 AS
 (
   SELECT 
             -1, 
            'U', 
            'U', 
            'U', 
            'U', 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            '12/31/1899', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            '12/31/1899', 
            'U', 
            'U', 
            'U', 
            'U', 
            0.0, 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            0.0, 
            'U', 
            'U', 
            'U', 
            'U', 
            'U', 
            -1, 
            -1, 
            0, 
            0, 
            0, 
            '12/31/1899', 
            '12/31/1899', 
            'U', 
            -1, 
            -1

 )
 
 INSERT INTO [Stage].[DimCustomer] 
 (
             CustomerKey, 
            CustomerID, 
            Customer, 
            CustomerLongName, 
            CustomerSearchName, 
            CompanyKey, 
            CommonCustomerKey, 
            ShipToAddressKey, 
            BillToAddressKey, 
            CurrencyKey, 
            SalesGroupKey, 
            CustomerCode, 
            CustomerCodeName, 
            CommonCustomerID, 
            CommonCustomerName, 
            CustomerCategoryID, 
            CustomerCategoryName, 
            CustomerGroup, 
            PhoneNumber, 
            FaxNumber, 
            CellNumber, 
            ContactName, 
            ContactPhone, 
            ContactEmail, 
            MainContact, 
            DateOpened, 
            BusinessLine, 
            AccountType, 
            Purpose, 
            Segment, 
            Language, 
            RegionalSalesManager, 
            CommissionGroup, 
            PriceGroup, 
            ItemGroup, 
            CollectorCode, 
            TaxGroup, 
            TaxResaleNumber, 
            TaxExpiration, 
            PaymentTermID, 
            PaymentTermName, 
            Discount, 
            LineDiscount, 
            CreditLimit, 
            CreditManager, 
            CreditRating, 
            CreditRiskType, 
            CreditBin, 
            CreditParentBin, 
            CustomerParent, 
            RebateCode, 
            Rebate, 
            MethodOfPayment, 
            Stopped, 
            AccountStatement, 
            Flag, 
            SpecialInstructions, 
            ExcludeFromInterest, 
            PrintInvoice, 
            IsNational, 
            IsArchived, 
            IsCurrent, 
            FromDate, 
            ToDate, 
            RowChangeReason, 
            InsertAuditKey, 
            UpdateAuditKey

 )
 SELECT * FROM CTE_DATA
 GO
 
 -- Set off
 SET IDENTITY_INSERT [Stage].[DimCustomer] OFF
 GO
 
 -- Execute a merge
 Exec [Mart].[MergeDimCustomer]
 GO
