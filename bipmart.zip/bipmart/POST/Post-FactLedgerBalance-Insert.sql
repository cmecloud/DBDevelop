/******************************************************
  *
  * Name:         Post-FactLedgerBalance-Insert.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Insert default record into [FactLedgerBalance]   
  *               table in [Stage] schema.
  *
  *               Call merge stored procedure to migrate
  *               to table in [Mart] schema.
  * 
  ******************************************************/

DELETE FROM [Mart].[FactLedgerBalance] WHERE FactLedgerBalanceKey = -1
BEGIN

 -- Set on
 SET IDENTITY_INSERT [Stage].[FactLedgerBalance] ON;
 GO
 
 -- Common Table Expression
 ;
 WITH CTE_DATA
 (
            FactLedgerBalanceKey, 
            DateKey, 
            CompanyKey, 
            AccountKey, 
            LedgerTransactionKey, 
            TransactionKey, 
            InsertAuditKey, 
            UpdateAuditKey, 
            DebitAmount, 
            CreditAmount, 
            Quantity

 )
 AS
 (
   SELECT 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            0, 
            0.0, 
            0.0

 )
 
 INSERT INTO [Stage].[FactLedgerBalance] 
 (
            FactLedgerBalanceKey, 
            DateKey, 
            CompanyKey, 
            AccountKey, 
            LedgerTransactionKey, 
            TransactionKey, 
            InsertAuditKey, 
            UpdateAuditKey, 
            DebitAmount, 
            CreditAmount, 
            Quantity

 )
 SELECT * FROM CTE_DATA
 GO
 
 -- Set off
 SET IDENTITY_INSERT [Stage].[FactLedgerBalance] OFF
 GO
 
 -- Execute a merge
 Exec [Mart].[MergeFactLedgerBalance]
 GO
