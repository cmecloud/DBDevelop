/******************************************************
  *
  * Name:         Post-FactSalesOrder-Insert.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Insert default record into [FactSalesOrder]   
  *               table in [Stage] schema.
  *
  *               Call merge stored procedure to migrate
  *               to table in [Mart] schema.
  * 
  ******************************************************/

 -- Set on
 SET IDENTITY_INSERT [Stage].[FactSalesOrder] ON;
 GO
 
 -- Common Table Expression
 ;
 WITH CTE_DATA
 (
             FactSalesOrderKey, 
            LocationKey, 
            CustomerKey, 
            EndCustomerKey, 
            ItemKey, 
            SalesGroupKey, 
            OrderDateKey, 
            DeliveryDateKey, 
            PromiseDateKey, 
            CurrencyKey, 
            TransactionKey, 
            InsertAuditKey, 
            UpdateAuditKey, 
            SalesOrderNumber, 
            SalesLineNumber, 
            IsSpecial, 
            IsSpecialInSpecial, 
            IsOnHold, 
            SalesUnit, 
            SalesAmount, 
            QuantitySold, 
            QuantityOrdered, 
            UnitPrice, 
            UnitCost, 
            Discount, 
            Freight, 
            FreightCost, 
            OverheadCostPct, 
            EngineeringHours, 
            LaborHours

 )
 AS
 (
   SELECT 
             -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            -1, 
            'U', 
            'U', 
            0, 
            0, 
            0, 
            'U', 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0, 
            0.0

 )
 
 INSERT INTO [Stage].[FactSalesOrder] 
 (
             FactSalesOrderKey, 
            LocationKey, 
            CustomerKey, 
            EndCustomerKey, 
            ItemKey, 
            SalesGroupKey, 
            OrderDateKey, 
            DeliveryDateKey, 
            PromiseDateKey, 
            CurrencyKey, 
            TransactionKey, 
            InsertAuditKey, 
            UpdateAuditKey, 
            SalesOrderNumber, 
            SalesLineNumber, 
            IsSpecial, 
            IsSpecialInSpecial, 
            IsOnHold, 
            SalesUnit, 
            SalesAmount, 
            QuantitySold, 
            QuantityOrdered, 
            UnitPrice, 
            UnitCost, 
            Discount, 
            Freight, 
            FreightCost, 
            OverheadCostPct, 
            EngineeringHours, 
            LaborHours

 )
 SELECT * FROM CTE_DATA
 GO
 
 -- Set off
 SET IDENTITY_INSERT [Stage].[FactSalesOrder] OFF
 GO
 
 -- Execute a merge
 EXECUTE [Mart].[MergeFactSalesOrder]
 GO