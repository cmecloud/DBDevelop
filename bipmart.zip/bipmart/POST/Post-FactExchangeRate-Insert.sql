/******************************************************
  *
  * Name:         Post-FactExchangeRate-Insert.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Insert default record into [FactExchangeRate]   
  *               table in [Stage] schema.
  *
  *               Call merge stored procedure to migrate
  *               to table in [Mart] schema.
  * 
  ******************************************************/
----Refresh
DELETE FROM [Mart].[FactExchangeRate] WHERE FactExchangeRateKey = -1
BEGIN
 -- Set on
 SET IDENTITY_INSERT [Stage].[FactExchangeRate] ON;
 GO
 
 -- Common Table Expression
 ;
 WITH CTE_DATA
 (
             FactExchangeRateKey, 
            DateKey, 
            SourceCurrencyKey, 
            DestinationCurrencyKey, 
            ExchangeRate, 
            InsertAuditKey, 
            UpdateAuditKey

 )
 AS
 (
   SELECT 
             -1, 
            -1, 
            -1, 
            -1, 
            0.0, 
            -1, 
            -1

 )
 
 INSERT INTO [Stage].[FactExchangeRate] 
 (
             FactExchangeRateKey, 
            DateKey, 
            SourceCurrencyKey, 
            DestinationCurrencyKey, 
            ExchangeRate, 
            InsertAuditKey, 
            UpdateAuditKey

 )
 SELECT * FROM CTE_DATA
 GO
 
 -- Set off
 SET IDENTITY_INSERT [Stage].[FactExchangeRate] OFF
 GO
 
 -- Execute a merge
 Exec [Mart].[MergeFactExchangeRate]
 GO
