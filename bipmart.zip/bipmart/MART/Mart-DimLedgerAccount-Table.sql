/******************************************************
  *
  * Name:         Mart-DimLedgerAccount-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimLedgerAccount]
  *               in the data [Mart] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Mart].[DimLedgerAccount] (
   [AccountKey] int IDENTITY NOT NULL
,  [AccountID] nvarchar(20) NULL
,  [AccountNumber] nvarchar(20) NULL
,  [AccountName] nvarchar(60) NULL
,  [AccountGroup] nvarchar(60) NULL
,  [AccountType] nvarchar(20) NULL
,  [ParentAccountID] nvarchar(20) NULL
,  [CompanyKey] int NULL
,  [AggregationBehavior] tinyint NULL
,  [AggregationOperator] nvarchar(10) NULL
,  [Unit] nvarchar(10) NULL
,  [IsExcludedDPO] bit NULL
,  [IsMovementAllowed] bit NULL
,  [IsLocked] bit NULL
,  [IsClosed] bit NULL
,  [IsSales] bit NULL
,  [IsNewOrders] bit NULL
,  [IsBacklog] bit NULL
,  [IsOverhead] bit NULL
,  [IsCurrent] bit NOT NULL
,  [FromDate] datetime NOT NULL
,  [ToDate] datetime  DEFAULT '12/31/9999' NOT NULL
,  [RowChangeReason] nvarchar(200) NOT NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
,  [HashKey] binary(16) NULL
,  [HashNonKey] binary(16) NULL
, CONSTRAINT [PK_Mart_DimLedgerAccount] PRIMARY KEY CLUSTERED 
( [AccountKey] )
) 
;

