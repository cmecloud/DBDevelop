/******************************************************
  *
  * Name:         Mart-DimCustomer-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimCustomer]
  *               in the data [Mart] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Mart].[DimCustomer] (
   [CustomerKey] int IDENTITY NOT NULL
,  [CustomerID] nvarchar(24) NOT NULL
,  [Customer] nvarchar(60) NOT NULL
,  [CustomerLongName] nvarchar(86) NOT NULL
,  [CustomerSearchName] nvarchar(30) NOT NULL
,  [CompanyKey] int NOT NULL
,  [CommonCustomerKey] int NOT NULL
,  [ShipToAddressKey] int NOT NULL
,  [BillToAddressKey] int NOT NULL
,  [CurrencyKey] int NOT NULL
,  [SalesGroupKey] int NOT NULL
,  [CustomerCode] nvarchar(15) NOT NULL
,  [CustomerCodeName] nvarchar(30) NOT NULL
,  [CommonCustomerID] nvarchar(24) NOT NULL
,  [CommonCustomerName] nvarchar(60) NOT NULL
,  [CustomerCategoryID] nvarchar(15) NOT NULL
,  [CustomerCategoryName] nvarchar(30) NOT NULL
,  [CustomerGroup] nvarchar(30) NOT NULL
,  [PhoneNumber] nvarchar(20) NOT NULL
,  [FaxNumber] nvarchar(20) NOT NULL
,  [CellNumber] nvarchar(20) NOT NULL
,  [ContactName] nvarchar(60) NOT NULL
,  [ContactPhone] nvarchar(20) NOT NULL
,  [ContactEmail] nvarchar(80) NOT NULL
,  [MainContact] nvarchar(20) NOT NULL
,  [DateOpened] date NOT NULL
,  [BusinessLine] nvarchar(15) NOT NULL
,  [AccountType] nvarchar(15) NOT NULL
,  [Purpose] nvarchar(15) NOT NULL
,  [Segment] nvarchar(20) NOT NULL
,  [Language] nvarchar(7) NOT NULL
,  [SalesDistrict] nvarchar(20) NOT NULL
,  [RegionalSalesManager] nvarchar(10) NOT NULL
,  [CommissionGroup] nvarchar(10) NOT NULL
,  [PriceGroup] nvarchar(10) NOT NULL
,  [ItemGroup] nvarchar(10) NOT NULL
,  [CollectorCode] nvarchar(10) NOT NULL
,  [TaxGroup] nvarchar(11) NOT NULL
,  [TaxResaleNumber] nvarchar(20) NOT NULL
,  [TaxExpiration] date NOT NULL
,  [PaymentTermID] nvarchar(20) NOT NULL
,  [PaymentTermName] nvarchar(60) NOT NULL
,  [Discount] nvarchar(20) NOT NULL
,  [LineDiscount] nvarchar(10) NOT NULL
,  [CreditLimit] money NOT NULL
,  [CreditManager] nvarchar(10) NOT NULL
,  [CreditRating] nvarchar(10) NOT NULL
,  [CreditRiskType] nvarchar(20) NOT NULL
,  [CreditBin] nvarchar(15) NOT NULL
,  [CreditParentBin] nvarchar(15) NOT NULL
,  [CustomerParent] nvarchar(60) NOT NULL
,  [RebateCode] nvarchar(10) NOT NULL
,  [Rebate] numeric(8,3) NOT NULL
,  [MethodOfPayment] nvarchar(10) NOT NULL
,  [Stopped] nvarchar(10) NOT NULL
,  [AccountStatement] nvarchar(10) NOT NULL
,  [Flag] nvarchar(10) NOT NULL
,  [SpecialInstructions] nvarchar(500) NOT NULL
,  [ExcludeFromInterest] bit NOT NULL
,  [PrintInvoice] bit NOT NULL
,  [IsNational] bit NOT NULL
,  [IsArchived] bit NOT NULL
,  [IsCurrent] bit NOT NULL
,  [FromDate] datetime NOT NULL
,  [ToDate] datetime  DEFAULT '12/31/9999' NOT NULL
,  [RowChangeReason] nvarchar(200) NOT NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
,  [HashKey] binary(16) NULL
,  [HashNonKey] binary(16) NULL
, CONSTRAINT [PK_Mart_DimCustomer] PRIMARY KEY CLUSTERED 
( [CustomerKey] )
) 
;

