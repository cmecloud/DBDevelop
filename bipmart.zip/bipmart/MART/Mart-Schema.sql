﻿/******************************************************
 *
 * Name:         Mart-Schema.sql
 *     
 * Design Phase:
 *     Author:   John Miner
 *     Date:     07-01-2018
 *     Purpose:  Create the [Mart] schema.
 * 
 ******************************************************/

CREATE SCHEMA [Mart] AUTHORIZATION [dbo];
GO