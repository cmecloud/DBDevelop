/******************************************************
  *
  * Name:         Mart-DimAddress-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimAddress]
  *               in the data [Mart] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Mart].[DimAddress] (
   [AddressKey] int IDENTITY NOT NULL
,  [AddressID] nvarchar(86) NOT NULL
,  [AddressLine1] nvarchar(250) NOT NULL
,  [Street] nvarchar(250) NOT NULL
,  [CountryID] nvarchar(10) NOT NULL
,  [CountryName] nvarchar(60) NOT NULL
,  [StateProvinceID] nvarchar(10) NOT NULL
,  [StateProvinceName] nvarchar(60) NOT NULL
,  [CityName] nvarchar(60) NOT NULL
,  [CountyName] nvarchar(30) NOT NULL
,  [ZipCode] nvarchar(10) NOT NULL
,  [IsCurrent] bit NOT NULL
,  [FromDate] datetime NOT NULL
,  [ToDate] datetime  DEFAULT '12/31/9999' NOT NULL
,  [RowChangeReason] nvarchar(200) NOT NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
,  [HashKey] binary(16) NULL
,  [HashNonKey] binary(16) NULL
, CONSTRAINT [PK_Mart_DimAddress] PRIMARY KEY CLUSTERED 
( [AddressKey] )
) 
;

