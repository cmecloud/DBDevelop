/******************************************************
  *
  * Name:         Mart-DimLocation-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimLocation]
  *               in the data [Mart] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Mart].[DimLocation] (
   [LocationKey] int IDENTITY NOT NULL
,  [LocationID] nvarchar(24) NOT NULL
,  [LocationName] nvarchar(60) NOT NULL
,  [SiteID] nvarchar(10) NULL
,  [SiteName] nvarchar(60) NULL
,  [CompanyKey] int NOT NULL
,  [IsCurrent] bit NOT NULL
,  [FromDate] datetime NOT NULL
,  [ToDate] datetime  DEFAULT '12/31/9999' NOT NULL
,  [RowChangeReason] nvarchar(200) NOT NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
,  [HashKey] binary(16) NULL
,  [HashNonKey] binary(16) NULL
, CONSTRAINT [PK_Mart_DimLocation] PRIMARY KEY CLUSTERED 
( [LocationKey] )
) 
;

