/******************************************************
  *
  * Name:         Mart-DimAudit-Table.sql
  *    
  * Design Phase:
  *     Author:   Cheryl Adams
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimAudit]
  *               in the data [Mart] schema. Edited CREATE STATEMENT
  * 
  ******************************************************/

  CREATE TABLE [Mart].[DimAudit] (
   [AuditKey] int IDENTITY NOT NULL
,  [LoadDate] datetime NOT NULL
,  [SourceFileName] varchar(500) NOT NULL
, [HashKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat([AuditKey], ''))))
, [HashNonKey] AS (Convert([varbinary](16), HashBytes('MD5', Concat(
    IsNull([LoadDate], '12/31/1899')
,   IsNull([SourceFileName], '.')
, ''))))
, CONSTRAINT [PK_Mark_DimAudit] PRIMARY KEY CLUSTERED 
( [AuditKey] )
) 
;


