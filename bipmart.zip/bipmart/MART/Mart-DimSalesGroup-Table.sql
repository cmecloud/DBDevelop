/******************************************************
  *
  * Name:         Mart-DimSalesGroup-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimSalesGroup]
  *               in the data [Mart] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Mart].[DimSalesGroup] (
   [SalesGroupKey] int IDENTITY NOT NULL
,  [SalesGroupID] nvarchar(14) NOT NULL
,  [SalesGroupCode] nvarchar(10) NULL
,  [SalesGroupName] nvarchar(60) NOT NULL
,  [CommissionRate] numeric(8,3) NOT NULL
,  [ItemCommissionGroup] nvarchar(20) NULL
,  [IsStopped] bit NULL
,  [IsCurrent] bit NOT NULL
,  [FromDate] datetime NOT NULL
,  [ToDate] datetime  DEFAULT '12/31/9999' NOT NULL
,  [RowChangeReason] nvarchar(200) NOT NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
,  [HashKey] binary(16) NULL
,  [HashNonKey] binary(16) NULL
, CONSTRAINT [PK_Mart_DimSalesGroup] PRIMARY KEY CLUSTERED 
( [SalesGroupKey] )
) 
;

