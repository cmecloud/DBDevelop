/******************************************************
  *
  * Name:         Mart-DimItem-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimItem]
  *               in the data [Mart] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Mart].[DimItem] (
   [ItemKey] int IDENTITY NOT NULL
,  [ItemID] nvarchar(24) NOT NULL
,  [ItemName] nvarchar(60) NOT NULL
,  [ItemText] nvarchar(1000) NOT NULL
,  [ItemSearchName] nvarchar(30) NULL
,  [LocationKey] int NOT NULL
,  [SubCategoryID] nvarchar(15) NOT NULL
,  [SubCategoryName] nvarchar(60) NULL
,  [CategoryID] nvarchar(15) NULL
,  [CategoryName] nvarchar(60) NULL
,  [ProductClassID] nvarchar(10) NULL
,  [ProductClassName] nvarchar(60) NULL
,  [SalesClassID] nvarchar(10) NULL
,  [SalesClassName] nvarchar(60) NULL
,  [Purpose] nvarchar(15) NULL
,  [BusinessLine] nvarchar(15) NULL
,  [ItemGroup] nvarchar(10) NULL
,  [FormGroup] nvarchar(20) NULL
,  [CommissionGroup] nvarchar(10) NULL
,  [DimensionGroup] nvarchar(10) NULL
,  [ModelGroup] nvarchar(10) NULL
,  [BuyerGroup] nvarchar(10) NULL
,  [CoverageGroup] nvarchar(10) NULL
,  [CountGroup] nvarchar(10) NULL
,  [CostGroup] nvarchar(10) NULL
,  [ItemType] nvarchar(10) NULL
,  [ItemTier] nvarchar(4) NULL
,  [UPCCarton] nvarchar(15) NULL
,  [UPCItem] nvarchar(15) NULL
,  [VitalityDate] date NULL
,  [PCAT] nvarchar(20) NULL
,  [PCATSub] nvarchar(20) NULL
,  [SKUFamily] nvarchar(20) NULL
,  [ShippingClass] nvarchar(30) NULL
,  [Form] nvarchar(20) NULL
,  [Mold] nvarchar(15) NULL
,  [Building] nvarchar(10) NULL
,  [BinLocation] nvarchar(10) NULL
,  [ProdABCD] char(1) NULL
,  [Scrap] nvarchar(10) NULL
,  [Weight] numeric(28,12) NULL
,  [WeightVariable] numeric(28,12) NULL
,  [WeightFixed] numeric(28,12) NULL
,  [ProdFlushing] nvarchar(10) NULL
,  [PrimaryVendor] nvarchar(20) NULL
,  [FreightPerLb] numeric(28,12) NULL
,  [ImbFreightCost] numeric(28,12) NULL
,  [Markup] numeric(28,12) NULL
,  [UnitConversionRatio] numeric(28,12) NULL
,  [SOUnit] nvarchar(10) NULL
,  [Price] money NULL
,  [Discount] money NULL
,  [POUnit] nvarchar(10) NULL
,  [POCost] money NULL
,  [InventoryUnit] nvarchar(10) NULL
,  [InventoryCost] money NULL
,  [BOMUnit] nvarchar(10) NULL
,  [IsExplicitFreight] bit NULL
,  [IsPhantom] bit NULL
,  [IsKit] bit NULL
,  [IsLatestPurchasePrice] bit NULL
,  [IsLatestCostPrice] bit NULL
,  [IsStopped] bit NULL
,  [IsCurrent] bit NOT NULL
,  [FromDate] datetime NOT NULL
,  [ToDate] datetime  DEFAULT '12/31/9999' NOT NULL
,  [RowChangeReason] nvarchar(200) NOT NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
,  [HashKey] binary(16) NULL
,  [HashNonKey] binary(16) NULL
, CONSTRAINT [PK_Mart_DimItem] PRIMARY KEY CLUSTERED 
( [ItemKey] )
) 
;

