/******************************************************
  *
  * Name:         Mart-DimLedgerTransaction-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimLedgerTransaction]
  *               in the data [Mart] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Mart].[DimLedgerTransaction] (
   [LedgerTransactionKey] int IDENTITY NOT NULL
,  [LedgerTransactionType] int NULL
,  [LedgerTransactionTypeName] nvarchar(30) NULL
,  [LedgerPostingTypeID] int NULL
,  [LedgerPostingTypeName] nvarchar(15) NULL
,  [RowChangeReason] nvarchar(200) NOT NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
,  [HashKey] binary(16) NULL
,  [HashNonKey] binary(16) NULL
, CONSTRAINT [PK_Mart_DimLedgerTransaction] PRIMARY KEY CLUSTERED 
( [LedgerTransactionKey] )
) 
;

