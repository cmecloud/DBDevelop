/******************************************************
  *
  * Name:         Mart-FactSalesOrder-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [FactSalesOrder]
  *               in the data [Mart] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Mart].[FactSalesOrder] (
   [FactSalesOrderKey] bigint NOT NULL
,  [LocationKey] int NOT NULL
,  [CustomerKey] int NOT NULL
,  [EndCustomerKey] int NULL
,  [ItemKey] int NOT NULL
,  [SalesGroupKey] int NOT NULL
,  [OrderDateKey] int NOT NULL
,  [DeliveryDateKey] int NOT NULL
,  [PromiseDateKey] int NOT NULL
,  [CurrencyKey] int NOT NULL
,  [TransactionKey] int NOT NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
,  [SalesOrderNumber] nvarchar(20) NULL
,  [SalesLineNumber] nvarchar(20) NULL
,  [IsSpecial] bit NOT NULL
,  [IsSpecialInSpecial] bit NULL
,  [IsOnHold] bit NOT NULL
,  [SalesUnit] nvarchar(10) NULL
,  [SalesAmount] money NULL
,  [QuantitySold] numeric(8,3) NULL
,  [QuantityOrdered] numeric(8,3) NULL
,  [UnitPrice] money NULL
,  [UnitCost] money NULL
,  [Discount] money NULL
,  [Freight] money NULL
,  [FreightCost] money NULL
,  [OverheadCostPct] numeric(5,2) NULL
,  [EngineeringHours] numeric(5,2) NULL
,  [LaborHours] numeric(5,2) NULL
,  [HashKey] binary(16) NULL
,  [HashNonKey] binary(16) NULL
, CONSTRAINT [PK_Mart_FactSalesOrder] PRIMARY KEY NONCLUSTERED 
( [FactSalesOrderKey] )
) 
;

