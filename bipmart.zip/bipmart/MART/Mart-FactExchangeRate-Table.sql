/******************************************************
  *
  * Name:         Mart-FactExchangeRate-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.C:\Users\cadamswo\source\repos\Old Castle\database project\bipmart\MART\Mart-FactExchangeRate-Table.sql
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [FactExchangeRate]
  *               in the data [Mart] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Mart].[FactExchangeRate] (
   [FactExchangeRateKey] int IDENTITY NOT NULL
,  [DateKey] int NULL
,  [SourceCurrencyKey] int NOT NULL
,  [DestinationCurrencyKey] int NOT NULL
,  [ExchangeRate] numeric(9,5) NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
,  [HashKey] binary(16) NULL
,  [HashNonKey] binary(16) NULL
, CONSTRAINT [PK_Mart_FactExchangeRate] PRIMARY KEY NONCLUSTERED 
( [FactExchangeRateKey] )
) 
;

