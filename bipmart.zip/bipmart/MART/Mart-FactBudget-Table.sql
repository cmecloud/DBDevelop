/******************************************************
  *
  * Name:         Mart-FactBudget-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [FactBudget]
  *               in the data [Mart] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Mart].[FactBudget] (
   [FactBudgetKey] bigint IDENTITY NOT NULL
,  [DateKey] int NOT NULL
,  [CompanyKey] int NOT NULL
,  [AccountKey] int NOT NULL
,  [TransactionKey] int NOT NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
,  [ModelNumber] nvarchar(10) NULL
,  [BudgetAmount] money NULL
,  [Quantity] numeric(28,12) NULL
,  [HashKey] binary(16) NULL
,  [HashNonKey] binary(16) NULL
, CONSTRAINT [PK_Mart_FactBudget] PRIMARY KEY NONCLUSTERED 
( [FactBudgetKey] )
) 
;

