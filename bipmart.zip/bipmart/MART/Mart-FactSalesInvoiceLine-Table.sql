/******************************************************
  *
  * Name:         Mart-FactSalesInvoiceLine-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [FactSalesInvoiceLine]
  *               in the data [Mart] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Mart].[FactSalesInvoiceLine] (
   [FactSalesInvoiceLineKey] bigint IDENTITY NOT NULL
,  [LocationKey] int NOT NULL
,  [CustomerKey] int NOT NULL
,  [OrderCustomerKey] int NOT NULL
,  [EndCustomerKey] int NOT NULL
,  [ItemKey] int NOT NULL
,  [SalesGroupKey] int NOT NULL
,  [InvoiceDateKey] int NOT NULL
,  [InvoiceDueDateKey] int NOT NULL
,  [DeliveryDateKey] int NOT NULL
,  [CurrencyKey] int NOT NULL
,  [DeliveryAddressKey] int NOT NULL
,  [CompanyKey]  int NOT NULL
,  [TransactionKey] int NOT NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
,  [SalesOrderNumber] nvarchar(20) NULL
,  [InvoiceNumber] nvarchar(20) NULL
,  [IsSpecial] bit NULL
,  [IsSpecialInSpecial] bit NULL
,  [DeliveryTerms] nvarchar(10) NULL
,  [DeliveryMode] nvarchar(10) NULL
,  [CommissionGroup] nvarchar(10) NULL
,  [Amount] money NULL
,  [Unit] nvarchar(10) NULL
,  [Quanity] numeric(8,3) NULL
,  [Commission] money NULL
,  [TaxAmount] money NULL
,  [TotalCost] money NULL
,  [UnitPrice] money NULL
,  [UnitCost] money NULL
,  [Discount] money NULL
,  [Freight] money NULL
,  [FreightCost] money NULL
,  [OverheadCostPct] numeric(5,2) NULL
,  [EngineeringHours] numeric(5,2) NULL
,  [LaborHours] numeric(5,2) NULL
,  [HashKey] binary(16) NULL
,  [HashNonKey] binary(16) NULL
, CONSTRAINT [PK_Mart_FactSalesInvoiceLine] PRIMARY KEY NONCLUSTERED 
( [FactSalesInvoiceLineKey] )
) 
;

