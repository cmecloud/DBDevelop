/******************************************************
  *
  * Name:         Mart-DimTransaction-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimTransaction]
  *               in the data [Mart] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Mart].[DimTransaction] (
   [TransactionKey] int IDENTITY NOT NULL
,  [CostCenter] nvarchar(15) NULL
,  [Department] nvarchar(15) NULL
,  [Type] nvarchar(15) NULL
,  [Purpose] nvarchar(15) NULL
,  [BusinessUnit] nvarchar(15) NULL
,  [RowChangeReason] nvarchar(200) NOT NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
,  [HashKey] binary(16) NULL
,  [HashNonKey] binary(16) NULL
, CONSTRAINT [PK_Mart_DimTransaction] PRIMARY KEY CLUSTERED 
( [TransactionKey] )
) 
;

