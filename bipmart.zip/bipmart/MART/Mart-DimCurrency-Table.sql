/******************************************************
  *
  * Name:         Mart-DimCurrency-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimCurrency]
  *               in the data [Mart] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Mart].[DimCurrency] (
   [CurrencyKey] int IDENTITY NOT NULL
,  [CurrencyID] nvarchar(3) NULL
,  [CurrencyName] nvarchar(20) NULL
,  [IsCurrent] bit NOT NULL
,  [FromDate] datetime NOT NULL
,  [ToDate] datetime  DEFAULT '12/31/9999' NOT NULL
,  [RowChangeReason] nvarchar(200) NOT NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
,  [HashKey] binary(16) NULL
,  [HashNonKey] binary(16) NULL
, CONSTRAINT [PK_Mart_DimCurrency] PRIMARY KEY CLUSTERED 
( [CurrencyKey] )
) 
;

