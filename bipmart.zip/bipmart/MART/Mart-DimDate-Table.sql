/******************************************************
  *
  * Name:         Mart-DimDate-Table.sql
  *    
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-24-2018
  *     Purpose:  Create the table named [DimDate]
  *               in the data [Mart] schema.
  * 
  ******************************************************/
 
CREATE TABLE [Mart].[DimDate] (
   [DateKey] int IDENTITY NOT NULL
,  [DateName] varchar(10) NOT NULL
,  [DateLongName] varchar(50) NOT NULL
,  [FiscalDayNumber] tinyint NOT NULL
,  [FiscalMonthID] int NOT NULL
,  [FiscalMonthNumber] tinyint NOT NULL
,  [FiscalMonthName] varchar(10) NOT NULL
,  [FiscalMonthBegin] date NOT NULL
,  [FiscalMonthEnd] date NOT NULL
,  [FiscalWeekNumber] tinyint NOT NULL
,  [FiscalWeekName] varchar(20) NOT NULL
,  [FiscalWeekBegin] date NOT NULL
,  [FiscalWeekEnd] date NOT NULL
,  [FiscalDayOfWeek] tinyint NOT NULL
,  [FiscalQuarterID] int NOT NULL
,  [FiscalQuarterNumber] tinyint NOT NULL
,  [FiscalQuarterName] varchar(10) NOT NULL
,  [FiscalQuarterBegin] datetime NOT NULL
,  [FiscalQuarterEnd] datetime NOT NULL
,  [FiscalDayOfQuarter] smallint NOT NULL
,  [FiscalYear] smallint NOT NULL
,  [FiscalYearBegin] datetime NOT NULL
,  [FiscalYearEnd] datetime NOT NULL
,  [FiscalDayOfYear] smallint NOT NULL
,  [IsCurrent] bit NOT NULL
,  [FromDate] datetime NOT NULL
,  [ToDate] datetime  DEFAULT '12/31/9999' NOT NULL
,  [RowChangeReason] nvarchar(200) NOT NULL
,  [InsertAuditKey] int NOT NULL
,  [UpdateAuditKey] int NOT NULL
,  [HashKey] binary(16) NULL
,  [HashNonKey] binary(16) NULL
, CONSTRAINT [PK_Mart_DimDate] PRIMARY KEY CLUSTERED 
( [DateKey] )
) 
;

