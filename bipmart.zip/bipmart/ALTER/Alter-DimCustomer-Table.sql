/******************************************************
  *
  * Name:         Alter-DimCustomer-Table.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Create constraints for [DimCustomer]   
  *               table in [Mart] schema.
  * 
  ******************************************************/

ALTER TABLE [Mart].[DimCustomer] ADD CONSTRAINT
   FK_Mart_DimCustomer_CompanyKey FOREIGN KEY
   (
   CompanyKey
   ) REFERENCES [Mart].[DimCompany]
   ( CompanyKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[DimCustomer] ADD CONSTRAINT
   FK_Mart_DimCustomer_CommonCustomerKey FOREIGN KEY
   (
   CommonCustomerKey
   ) REFERENCES [Mart].[DimCustomer]
   ( CustomerKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[DimCustomer] ADD CONSTRAINT
   FK_Mart_DimCustomer_ShipToAddressKey FOREIGN KEY
   (
   ShipToAddressKey
   ) REFERENCES [Mart].[DimAddress]
   ( AddressKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[DimCustomer] ADD CONSTRAINT
   FK_Mart_DimCustomer_BillToAddressKey FOREIGN KEY
   (
   BillToAddressKey
   ) REFERENCES [Mart].[DimAddress]
   ( AddressKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[DimCustomer] ADD CONSTRAINT
   FK_Mart_DimCustomer_CurrencyKey FOREIGN KEY
   (
   CurrencyKey
   ) REFERENCES [Mart].[DimCurrency]
   ( CurrencyKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[DimCustomer] ADD CONSTRAINT
   FK_Mart_DimCustomer_SalesGroupKey FOREIGN KEY
   (
   SalesGroupKey
   ) REFERENCES [Mart].[DimSalesGroup]
   ( SalesGroupKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[DimCustomer] ADD CONSTRAINT
   FK_Mart_DimCustomer_InsertAuditKey FOREIGN KEY
   (
   InsertAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[DimCustomer] ADD CONSTRAINT
   FK_Mart_DimCustomer_UpdateAuditKey FOREIGN KEY
   (
   UpdateAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO

