/******************************************************
  *
  * Name:         Alter-DimCompany-Table.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Create constraints for [DimCompany]   
  *               table in [Mart] schema.
  * 
  ******************************************************/

ALTER TABLE [Mart].[DimCompany] ADD CONSTRAINT
   FK_Mart_DimCompany_CompanyAddress FOREIGN KEY
   (
   CompanyAddress
   ) REFERENCES [Mart].[DimAddress]
   ( AddressKey)
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[DimCompany] ADD CONSTRAINT
   FK_Mart_DimCompany_InsertAuditKey FOREIGN KEY
   (
   InsertAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[DimCompany] ADD CONSTRAINT
   FK_Mart_DimCompany_UpdateAuditKey FOREIGN KEY
   (
   UpdateAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO
