/******************************************************
  *
  * Name:         Alter-FactSalesOrderLine-Table.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Create constraints for [FactSalesOrderLine]   
  *               table in [Mart] schema.
  * 
  ******************************************************/

ALTER TABLE [Mart].[FactSalesOrderLine] ADD CONSTRAINT
   FK_Mart_FactSalesOrderLine_LocationKey FOREIGN KEY
   (
   LocationKey
   ) REFERENCES [Mart].[DimLocation]
   ( LocationKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrderLine] ADD CONSTRAINT
   FK_Mart_FactSalesOrderLine_CustomerKey FOREIGN KEY
   (
   CustomerKey
   ) REFERENCES [Mart].[DimCustomer]
   ( CustomerKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrderLine] ADD CONSTRAINT
   FK_Mart_FactSalesOrderLine_EndCustomerKey FOREIGN KEY
   (
   EndCustomerKey
   ) REFERENCES [Mart].[DimCustomer]
   ( CustomerKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrderLine] ADD CONSTRAINT
   FK_Mart_FactSalesOrderLine_ItemKey FOREIGN KEY
   (
   ItemKey
   ) REFERENCES [Mart].[DimItem]
   ( ItemKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrderLine] ADD CONSTRAINT
   FK_Mart_FactSalesOrderLine_SalesGroupKey FOREIGN KEY
   (
   SalesGroupKey
   ) REFERENCES [Mart].[DimSalesGroup]
   ( SalesGroupKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrderLine] ADD CONSTRAINT
   FK_Mart_FactSalesOrderLine_OrderDateKey FOREIGN KEY
   (
   OrderDateKey
   ) REFERENCES [Mart].[DimDate]
   ( DateKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrderLine] ADD CONSTRAINT
   FK_Mart_FactSalesOrderLine_DeliveryDateKey FOREIGN KEY
   (
   DeliveryDateKey
   ) REFERENCES [Mart].[DimDate]
   ( DateKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrderLine] ADD CONSTRAINT
   FK_Mart_FactSalesOrderLine_PromiseDateKey FOREIGN KEY
   (
   PromiseDateKey
   ) REFERENCES [Mart].[DimDate]
   ( DateKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrderLine] ADD CONSTRAINT
   FK_Mart_FactSalesOrderLine_CurrencyKey FOREIGN KEY
   (
   CurrencyKey
   ) REFERENCES [Mart].[DimCurrency]
   ( CurrencyKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrderLine] ADD CONSTRAINT
   FK_Mart_FactSalesOrderLine_TransactionKey FOREIGN KEY
   (
   TransactionKey
   ) REFERENCES [Mart].[DimTransaction]
   ( TransactionKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrderLine] ADD CONSTRAINT
   FK_Mart_FactSalesOrderLine_InsertAuditKey FOREIGN KEY
   (
   InsertAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrderLine] ADD CONSTRAINT
   FK_Mart_FactSalesOrderLine_UpdateAuditKey FOREIGN KEY
   (
   UpdateAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO

