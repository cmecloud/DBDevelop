/******************************************************
  *
  * Name:         Alter-DimLocation-Table.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Create constraints for [DimLocation]   
  *               table in [Mart] schema.
  * 
  ******************************************************/

ALTER TABLE [Mart].[DimLocation] ADD CONSTRAINT
   FK_Mart_DimLocation_CompanyKey FOREIGN KEY
   (
   CompanyKey
   ) REFERENCES [Mart].[DimCompany]
   ( CompanyKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[DimLocation] ADD CONSTRAINT
   FK_Mart_DimLocation_InsertAuditKey FOREIGN KEY
   (
   InsertAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[DimLocation] ADD CONSTRAINT
   FK_Mart_DimLocation_UpdateAuditKey FOREIGN KEY
   (
   UpdateAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO

