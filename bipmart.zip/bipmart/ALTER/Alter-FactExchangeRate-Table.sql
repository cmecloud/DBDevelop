/******************************************************
  *
  * Name:         Alter-FactExchangeRate-Table.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Create constraints for [FactExchangeRate]   
  *               table in [Mart] schema.
  * 
  ******************************************************/

ALTER TABLE [Mart].[FactExchangeRate] ADD CONSTRAINT
   FK_Mart_FactExchangeRate_DateKey FOREIGN KEY
   (
   DateKey
   ) REFERENCES [Mart].[DimDate]
   ( DateKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactExchangeRate] ADD CONSTRAINT
   FK_Mart_FactExchangeRate_SourceCurrencyKey FOREIGN KEY
   (
   SourceCurrencyKey
   ) REFERENCES [Mart].[DimCurrency]
   ( CurrencyKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactExchangeRate] ADD CONSTRAINT
   FK_Mart_FactExchangeRate_DestinationCurrencyKey FOREIGN KEY
   (
   DestinationCurrencyKey
   ) REFERENCES [Mart].[DimCurrency]
   ( CurrencyKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactExchangeRate] ADD CONSTRAINT
   FK_Mart_FactExchangeRate_InsertAuditKey FOREIGN KEY
   (
   InsertAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactExchangeRate] ADD CONSTRAINT
   FK_Mart_FactExchangeRate_UpdateAuditKey FOREIGN KEY
   (
   UpdateAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO
