/******************************************************
  *
  * Name:         Alter-DimLedgerTransaction-Table.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Create constraints for [DimLedgerTransaction]   
  *               table in [Mart] schema.
  * 
  ******************************************************/

ALTER TABLE [Mart].[DimLedgerTransaction] ADD CONSTRAINT
   FK_Mart_DimLedgerTransaction_InsertAuditKey FOREIGN KEY
   (
   InsertAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[DimLedgerTransaction] ADD CONSTRAINT
   FK_Mart_DimLedgerTransaction_UpdateAuditKey FOREIGN KEY
   (
   UpdateAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO

