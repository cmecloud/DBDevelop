/******************************************************
  *
  * Name:         Alter-FactSalesOrder-Table.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Create constraints for [FactSalesOrder]   
  *               table in [Mart] schema.
  * 
  ******************************************************/

ALTER TABLE [Mart].[FactSalesOrder] ADD CONSTRAINT
   FK_Mart_FactSalesOrder_LocationKey FOREIGN KEY
   (
   LocationKey
   ) REFERENCES [Mart].[DimLocation]
   ( LocationKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrder] ADD CONSTRAINT
   FK_Mart_FactSalesOrder_CustomerKey FOREIGN KEY
   (
   CustomerKey
   ) REFERENCES [Mart].[DimCustomer]
   ( CustomerKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrder] ADD CONSTRAINT
   FK_Mart_FactSalesOrder_EndCustomerKey FOREIGN KEY
   (
   EndCustomerKey
   ) REFERENCES [Mart].[DimCustomer]
   ( CustomerKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrder] ADD CONSTRAINT
   FK_Mart_FactSalesOrder_ItemKey FOREIGN KEY
   (
   ItemKey
   ) REFERENCES [Mart].[DimItem]
   ( ItemKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrder] ADD CONSTRAINT
   FK_Mart_FactSalesOrder_SalesGroupKey FOREIGN KEY
   (
   SalesGroupKey
   ) REFERENCES [Mart].[DimSalesGroup]
   ( SalesGroupKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrder] ADD CONSTRAINT
   FK_Mart_FactSalesOrder_OrderDateKey FOREIGN KEY
   (
   OrderDateKey
   ) REFERENCES [Mart].[DimDate]
   ( DateKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrder] ADD CONSTRAINT
   FK_Mart_FactSalesOrder_DeliveryDateKey FOREIGN KEY
   (
   DeliveryDateKey
   ) REFERENCES [Mart].[DimDate]
   ( DateKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrder] ADD CONSTRAINT
   FK_Mart_FactSalesOrder_PromiseDateKey FOREIGN KEY
   (
   PromiseDateKey
   ) REFERENCES [Mart].[DimDate]
   ( DateKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrder] ADD CONSTRAINT
   FK_Mart_FactSalesOrder_CurrencyKey FOREIGN KEY
   (
   CurrencyKey
   ) REFERENCES [Mart].[DimCurrency]
   ( CurrencyKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrder] ADD CONSTRAINT
   FK_Mart_FactSalesOrder_TransactionKey FOREIGN KEY
   (
   TransactionKey
   ) REFERENCES [Mart].[DimTransaction]
   ( TransactionKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrder] ADD CONSTRAINT
   FK_Mart_FactSalesOrder_InsertAuditKey FOREIGN KEY
   (
   InsertAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesOrder] ADD CONSTRAINT
   FK_Mart_FactSalesOrder_UpdateAuditKey FOREIGN KEY
   (
   UpdateAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO

