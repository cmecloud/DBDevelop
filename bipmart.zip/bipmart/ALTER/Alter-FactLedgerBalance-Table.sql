/******************************************************
  *
  * Name:         Alter-FactLedgerBalance-Table.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Create constraints for [FactLedgerBalance]   
  *               table in [Mart] schema.
  * 
  ******************************************************/

ALTER TABLE [Mart].[FactLedgerBalance] ADD CONSTRAINT
   FK_Mart_FactLedgerBalance_DateKey FOREIGN KEY
   (
   DateKey
   ) REFERENCES [Mart].[DimDate]
   ( DateKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactLedgerBalance] ADD CONSTRAINT
   FK_Mart_FactLedgerBalance_CompanyKey FOREIGN KEY
   (
   CompanyKey
   ) REFERENCES [Mart].[DimCompany]
   ( CompanyKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactLedgerBalance] ADD CONSTRAINT
   FK_Mart_FactLedgerBalance_AccountKey FOREIGN KEY
   (
   AccountKey
   ) REFERENCES [Mart].[DimLedgerAccount]
   ( AccountKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactLedgerBalance] ADD CONSTRAINT
   FK_Mart_FactLedgerBalance_LedgerTransactionKey FOREIGN KEY
   (
   LedgerTransactionKey
   ) REFERENCES [Mart].[DimLedgerTransaction]
   ( LedgerTransactionKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactLedgerBalance] ADD CONSTRAINT
   FK_Mart_FactLedgerBalance_TransactionKey FOREIGN KEY
   (
   TransactionKey
   ) REFERENCES [Mart].[DimTransaction]
   ( TransactionKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactLedgerBalance] ADD CONSTRAINT
   FK_Mart_FactLedgerBalance_InsertAuditKey FOREIGN KEY
   (
   InsertAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactLedgerBalance] ADD CONSTRAINT
   FK_Mart_FactLedgerBalance_UpdateAuditKey FOREIGN KEY
   (
   UpdateAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO
