/******************************************************
  *
  * Name:         Alter-DimCurrency-Table.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Create constraints for [DimCurrency]   
  *               table in [Mart] schema.
  * 
  ******************************************************/

ALTER TABLE [Mart].[DimCurrency] ADD CONSTRAINT
   FK_Mart_DimCurrency_InsertAuditKey FOREIGN KEY
   (
   InsertAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[DimCurrency] ADD CONSTRAINT
   FK_Mart_DimCurrency_UpdateAuditKey FOREIGN KEY
   (
   UpdateAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO
