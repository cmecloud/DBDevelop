/******************************************************
  *
  * Name:         Alter-FactSalesInvoice-Table.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Create constraints for [FactSalesInvoice]   
  *               table in [Mart] schema.
  * 
  ******************************************************/

ALTER TABLE [Mart].[FactSalesInvoice] ADD CONSTRAINT
   FK_Mart_FactSalesInvoice_LocationKey FOREIGN KEY
   (
   LocationKey
   ) REFERENCES [Mart].[DimLocation]
   ( LocationKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoice] ADD CONSTRAINT
   FK_Mart_FactSalesInvoice_CustomerKey FOREIGN KEY
   (
   CustomerKey
   ) REFERENCES [Mart].[DimCustomer]
   ( CustomerKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoice] ADD CONSTRAINT
   FK_Mart_FactSalesInvoice_OrderCustomerKey FOREIGN KEY
   (
   OrderCustomerKey
   ) REFERENCES [Mart].[DimCustomer]
   ( CustomerKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoice] ADD CONSTRAINT
   FK_Mart_FactSalesInvoice_EndCustomerKey FOREIGN KEY
   (
   EndCustomerKey
   ) REFERENCES [Mart].[DimCustomer]
   ( CustomerKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoice] ADD CONSTRAINT
   FK_Mart_FactSalesInvoice_ItemKey FOREIGN KEY
   (
   ItemKey
   ) REFERENCES [Mart].[DimItem]
   ( ItemKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoice] ADD CONSTRAINT
   FK_Mart_FactSalesInvoice_SalesGroupKey FOREIGN KEY
   (
   SalesGroupKey
   ) REFERENCES [Mart].[DimSalesGroup]
   ( SalesGroupKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoice] ADD CONSTRAINT
   FK_Mart_FactSalesInvoice_InvoiceDateKey FOREIGN KEY
   (
   InvoiceDateKey
   ) REFERENCES [Mart].[DimDate]
   ( DateKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoice] ADD CONSTRAINT
   FK_Mart_FactSalesInvoice_InvoiceDueDateKey FOREIGN KEY
   (
   InvoiceDueDateKey
   ) REFERENCES [Mart].[DimDate]
   ( DateKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoice] ADD CONSTRAINT
   FK_Mart_FactSalesInvoice_DeliveryDateKey FOREIGN KEY
   (
   DeliveryDateKey
   ) REFERENCES [Mart].[DimDate]
   ( DateKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoice] ADD CONSTRAINT
   FK_Mart_FactSalesInvoice_CurrencyKey FOREIGN KEY
   (
   CurrencyKey
   ) REFERENCES [Mart].[DimCurrency]
   ( CurrencyKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoice] ADD CONSTRAINT
   FK_Mart_FactSalesInvoice_DeliveryAddressKey FOREIGN KEY
   (
   DeliveryAddressKey
   ) REFERENCES [Mart].[DimAddress]
   ( AddressKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoice] ADD CONSTRAINT
   FK_Mart_FactSalesInvoice_TransactionKey FOREIGN KEY
   (
   TransactionKey
   ) REFERENCES [Mart].[DimTransaction]
   ( TransactionKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoice] ADD CONSTRAINT
   FK_Mart_FactSalesInvoice_InsertAuditKey FOREIGN KEY
   (
   InsertAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoice] ADD CONSTRAINT
   FK_Mart_FactSalesInvoice_UpdateAuditKey FOREIGN KEY
   (
   UpdateAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO
