/******************************************************
  *
  * Name:         Alter-DimSalesGroup-Table.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Create constraints for [DimSalesGroup]   
  *               table in [Mart] schema.
  * 
  ******************************************************/

ALTER TABLE [Mart].[DimSalesGroup] ADD CONSTRAINT
   FK_Mart_DimSalesGroup_InsertAuditKey FOREIGN KEY
   (
   InsertAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[DimSalesGroup] ADD CONSTRAINT
   FK_Mart_DimSalesGroup_UpdateAuditKey FOREIGN KEY
   (
   UpdateAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO

