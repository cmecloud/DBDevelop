/******************************************************
  *
  * Name:         Alter-FactSalesInvoiceLine-Table.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Create constraints for [FactSalesInvoiceLine]   
  *               table in [Mart] schema.
  * 
  ******************************************************/

ALTER TABLE [Mart].[FactSalesInvoiceLine] ADD CONSTRAINT
   FK_Mart_FactSalesInvoiceLine_LocationKey FOREIGN KEY
   (
   LocationKey
   ) REFERENCES [Mart].[DimLocation]
   ( LocationKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoiceLine] ADD CONSTRAINT
   FK_Mart_FactSalesInvoiceLine_CustomerKey FOREIGN KEY
   (
   CustomerKey
   ) REFERENCES [Mart].[DimCustomer]
   ( CustomerKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoiceLine] ADD CONSTRAINT
   FK_Mart_FactSalesInvoiceLine_OrderCustomerKey FOREIGN KEY
   (
   OrderCustomerKey
   ) REFERENCES [Mart].[DimCustomer]
   ( CustomerKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoiceLine] ADD CONSTRAINT
   FK_Mart_FactSalesInvoiceLine_EndCustomerKey FOREIGN KEY
   (
   EndCustomerKey
   ) REFERENCES [Mart].[DimCustomer]
   ( CustomerKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoiceLine] ADD CONSTRAINT
   FK_Mart_FactSalesInvoiceLine_ItemKey FOREIGN KEY
   (
   ItemKey
   ) REFERENCES [Mart].[DimItem]
   ( ItemKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoiceLine] ADD CONSTRAINT
   FK_Mart_FactSalesInvoiceLine_SalesGroupKey FOREIGN KEY
   (
   SalesGroupKey
   ) REFERENCES [Mart].[DimSalesGroup]
   ( SalesGroupKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoiceLine] ADD CONSTRAINT
   FK_Mart_FactSalesInvoiceLine_InvoiceDateKey FOREIGN KEY
   (
   InvoiceDateKey
   ) REFERENCES [Mart].[DimDate]
   ( DateKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoiceLine] ADD CONSTRAINT
   FK_Mart_FactSalesInvoiceLine_InvoiceDueDateKey FOREIGN KEY
   (
   InvoiceDueDateKey
   ) REFERENCES [Mart].[DimDate]
   ( DateKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoiceLine] ADD CONSTRAINT
   FK_Mart_FactSalesInvoiceLine_DeliveryDateKey FOREIGN KEY
   (
   DeliveryDateKey
   ) REFERENCES [Mart].[DimDate]
   ( DateKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoiceLine] ADD CONSTRAINT
   FK_Mart_FactSalesInvoiceLine_CurrencyKey FOREIGN KEY
   (
   CurrencyKey
   ) REFERENCES [Mart].[DimCurrency]
   ( CurrencyKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoiceLine] ADD CONSTRAINT
   FK_Mart_FactSalesInvoiceLine_DeliveryAddressKey FOREIGN KEY
   (
   DeliveryAddressKey
   ) REFERENCES [Mart].[DimAddress]
   ( AddressKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoiceLine] ADD CONSTRAINT
   FK_Mart_FactSalesInvoiceLine_TransactionKey FOREIGN KEY
   (
   TransactionKey
   ) REFERENCES [Mart].[DimTransaction]
   ( TransactionKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoiceLine] ADD CONSTRAINT
   FK_Mart_FactSalesInvoiceLine_InsertAuditKey FOREIGN KEY
   (
   InsertAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactSalesInvoiceLine] ADD CONSTRAINT
   FK_Mart_FactSalesInvoiceLine_UpdateAuditKey FOREIGN KEY
   (
   UpdateAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO
