/******************************************************
  *
  * Name:         Alter-FactBudget-Table.sql
  *    
  * Design Phase:
  *     Author:   System generated.
  *     Date:     07-16-2018
  *     Purpose:  Create constraints for [FactBudget]   
  *               table in [Mart] schema.
  * 
  ******************************************************/

ALTER TABLE [Mart].[FactBudget] ADD CONSTRAINT
   FK_Mart_FactBudget_DateKey FOREIGN KEY
   (
   DateKey
   ) REFERENCES [Mart].[DimDate]
   ( DateKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactBudget] ADD CONSTRAINT
   FK_Mart_FactBudget_CompanyKey FOREIGN KEY
   (
   CompanyKey
   ) REFERENCES [Mart].[DimCompany]
   ( CompanyKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactBudget] ADD CONSTRAINT
   FK_Mart_FactBudget_AccountKey FOREIGN KEY
   (
   AccountKey
   ) REFERENCES [Mart].[DimLedgerAccount]
   ( AccountKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactBudget] ADD CONSTRAINT
   FK_Mart_FactBudget_TransactionKey FOREIGN KEY
   (
   TransactionKey
   ) REFERENCES[Mart].[DimTransaction]
   ( TransactionKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactBudget] ADD CONSTRAINT
   FK_Mart_FactBudget_InsertAuditKey FOREIGN KEY
   (
   InsertAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO


ALTER TABLE [Mart].[FactBudget] ADD CONSTRAINT
   FK_Mart_FactBudget_UpdateAuditKey FOREIGN KEY
   (
   UpdateAuditKey
   ) REFERENCES [Mart].[DimAudit]
   ( AuditKey )
     ON UPDATE  NO ACTION
     ON DELETE  NO ACTION
;
GO

