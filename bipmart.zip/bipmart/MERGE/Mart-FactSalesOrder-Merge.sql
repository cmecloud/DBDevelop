/******************************************************
  *
  * Name:         Mart-FactSalesOrder-Merge.sql
  *     
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-01-2018
  *     Purpose:  Merge [FactSalesOrder] table data
  *               in [Stage] with data in [Mart].
  * 
  ******************************************************/
 
 CREATE PROCEDURE [Mart].[MergeFactSalesOrder]
 AS
 
     -- Merge between Target & Source
     MERGE 
         [Mart].[FactSalesOrder] AS Trg
     USING 
     (
         SELECT * FROM [Stage].[FactSalesOrder]
     ) AS Src ON Src.[HashKey] = Trg.[HashKey] 
 
     -- Update condition
     WHEN MATCHED AND (Src.HashNonKey <> Trg.HashNonKey) THEN 
         UPDATE SET
            [FactSalesOrderKey] = Src.[FactSalesOrderKey], 
            [LocationKey] = Src.[LocationKey], 
            [CustomerKey] = Src.[CustomerKey], 
            [EndCustomerKey] = Src.[EndCustomerKey], 
            [ItemKey] = Src.[ItemKey], 
            [SalesGroupKey] = Src.[SalesGroupKey], 
            [OrderDateKey] = Src.[OrderDateKey], 
            [DeliveryDateKey] = Src.[DeliveryDateKey], 
            [PromiseDateKey] = Src.[PromiseDateKey], 
            [CurrencyKey] = Src.[CurrencyKey], 
            [TransactionKey] = Src.[TransactionKey], 
            [InsertAuditKey] = Src.[InsertAuditKey], 
            [UpdateAuditKey] = Src.[UpdateAuditKey], 
            [SalesOrderNumber] = Src.[SalesOrderNumber], 
            [SalesLineNumber] = Src.[SalesLineNumber], 
            [IsSpecial] = Src.[IsSpecial], 
            [IsSpecialInSpecial] = Src.[IsSpecialInSpecial], 
            [IsOnHold] = Src.[IsOnHold], 
            [SalesUnit] = Src.[SalesUnit], 
            [SalesAmount] = Src.[SalesAmount], 
            [QuantitySold] = Src.[QuantitySold], 
            [QuantityOrdered] = Src.[QuantityOrdered], 
            [UnitPrice] = Src.[UnitPrice], 
            [UnitCost] = Src.[UnitCost], 
            [Discount] = Src.[Discount], 
            [Freight] = Src.[Freight], 
            [FreightCost] = Src.[FreightCost], 
            [OverheadCostPct] = Src.[OverheadCostPct], 
            [EngineeringHours] = Src.[EngineeringHours], 
            [LaborHours] = Src.[LaborHours], 
            [HashKey] = Src.[HashKey], 
            [HashNonKey] = Src.[HashNonKey]

      
     -- Delete condition (skip default)
     WHEN NOT MATCHED BY SOURCE AND (Trg.[FactSalesOrderKey] <> -1) THEN DELETE
 
     -- Insert condition
     WHEN NOT MATCHED BY TARGET THEN
         INSERT
         (
            [FactSalesOrderKey], 
            [LocationKey], 
            [CustomerKey], 
            [EndCustomerKey], 
            [ItemKey], 
            [SalesGroupKey], 
            [OrderDateKey], 
            [DeliveryDateKey], 
            [PromiseDateKey], 
            [CurrencyKey], 
            [TransactionKey], 
            [InsertAuditKey], 
            [UpdateAuditKey], 
            [SalesOrderNumber], 
            [SalesLineNumber], 
            [IsSpecial], 
            [IsSpecialInSpecial], 
            [IsOnHold], 
            [SalesUnit], 
            [SalesAmount], 
            [QuantitySold], 
            [QuantityOrdered], 
            [UnitPrice], 
            [UnitCost], 
            [Discount], 
            [Freight], 
            [FreightCost], 
            [OverheadCostPct], 
            [EngineeringHours], 
            [LaborHours], 
            [HashKey], 
            [HashNonKey]
         )
         VALUES
         ( 
            Src.[FactSalesOrderKey], 
            Src.[LocationKey], 
            Src.[CustomerKey], 
            Src.[EndCustomerKey], 
            Src.[ItemKey], 
            Src.[SalesGroupKey], 
            Src.[OrderDateKey], 
            Src.[DeliveryDateKey], 
            Src.[PromiseDateKey], 
            Src.[CurrencyKey], 
            Src.[TransactionKey], 
            Src.[InsertAuditKey], 
            Src.[UpdateAuditKey], 
            Src.[SalesOrderNumber], 
            Src.[SalesLineNumber], 
            Src.[IsSpecial], 
            Src.[IsSpecialInSpecial], 
            Src.[IsOnHold], 
            Src.[SalesUnit], 
            Src.[SalesAmount], 
            Src.[QuantitySold], 
            Src.[QuantityOrdered], 
            Src.[UnitPrice], 
            Src.[UnitCost], 
            Src.[Discount], 
            Src.[Freight], 
            Src.[FreightCost], 
            Src.[OverheadCostPct], 
            Src.[EngineeringHours], 
            Src.[LaborHours], 
            Src.[HashKey], 
            Src.[HashNonKey]
         );
 
 GO
