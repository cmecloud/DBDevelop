/******************************************************
  *
  * Name:         Mart-DimSalesGroup-Merge.sql
  *     
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-01-2018
  *     Purpose:  Merge [DimSalesGroup] table data
  *               in [Stage] with data in [Mart].
  * 
  ******************************************************/
 
 CREATE PROCEDURE [Mart].[MergeDimSalesGroup]
 AS
 
     -- Merge between Target & Source
     MERGE 
         [Mart].[DimSalesGroup] AS Trg
     USING 
     (
         SELECT * FROM [Stage].[DimSalesGroup]
     ) AS Src ON Src.[HashKey] = Trg.[HashKey] 
 
     -- Update condition
     WHEN MATCHED AND (Src.HashNonKey <> Trg.HashNonKey) THEN 
         UPDATE SET
            [SalesGroupKey] = Src.[SalesGroupKey], 
            [SalesGroupID] = Src.[SalesGroupID], 
            [SalesGroupCode] = Src.[SalesGroupCode], 
            [SalesGroupName] = Src.[SalesGroupName], 
            [CommissionRate] = Src.[CommissionRate], 
            [ItemCommissionGroup] = Src.[ItemCommissionGroup], 
            [IsStopped] = Src.[IsStopped], 
            [IsCurrent] = Src.[IsCurrent], 
            [FromDate] = Src.[FromDate], 
            [ToDate] = Src.[ToDate], 
            [RowChangeReason] = Src.[RowChangeReason], 
            [InsertAuditKey] = Src.[InsertAuditKey], 
            [UpdateAuditKey] = Src.[UpdateAuditKey], 
            [HashKey] = Src.[HashKey], 
            [HashNonKey] = Src.[HashNonKey]

      
     -- Delete condition (skip default)
     WHEN NOT MATCHED BY SOURCE AND (Trg.[SalesGroupKey] <> -1) THEN
	     UPDATE SET
		         [IsCurrent] = 0
 
     -- Insert condition
     WHEN NOT MATCHED BY TARGET THEN
         INSERT
         (
            [SalesGroupKey], 
            [SalesGroupID], 
            [SalesGroupCode], 
            [SalesGroupName], 
            [CommissionRate], 
            [ItemCommissionGroup], 
            [IsStopped], 
            [IsCurrent], 
            [FromDate], 
            [ToDate], 
            [RowChangeReason], 
            [InsertAuditKey], 
            [UpdateAuditKey], 
            [HashKey], 
            [HashNonKey]
         )
         VALUES
         ( 
            Src.[SalesGroupKey], 
            Src.[SalesGroupID], 
            Src.[SalesGroupCode], 
            Src.[SalesGroupName], 
            Src.[CommissionRate], 
            Src.[ItemCommissionGroup], 
            Src.[IsStopped], 
            Src.[IsCurrent], 
            Src.[FromDate], 
            Src.[ToDate], 
            Src.[RowChangeReason], 
            Src.[InsertAuditKey], 
            Src.[UpdateAuditKey], 
            Src.[HashKey], 
            Src.[HashNonKey]
         );
 
 GO
