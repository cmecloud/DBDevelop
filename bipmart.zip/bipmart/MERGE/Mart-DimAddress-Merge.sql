/******************************************************
  *
  * Name:         Mart-DimAddress-Merge.sql
  *     
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-01-2018
  *     Purpose:  Merge [DimAddress] table data
  *               in [Stage] with data in [Mart].
  * 
  ******************************************************/
 
 CREATE PROCEDURE [Mart].[MergeDimAddress]
 AS
 
     -- Merge between Target & Source
     MERGE 
         [Mart].[DimAddress] AS Trg
     USING 
     (
         SELECT * FROM [Stage].[DimAddress]
     ) AS Src ON Src.[HashKey] = Trg.[HashKey] 
 
     -- Update condition
     WHEN MATCHED AND (Src.HashNonKey <> Trg.HashNonKey) THEN 
         UPDATE SET
            [AddressKey] = Src.[AddressKey], 
            [AddressID] = Src.[AddressID], 
            [AddressLine1] = Src.[AddressLine1], 
            [Street] = Src.[Street], 
            [CountryID] = Src.[CountryID], 
            [CountryName] = Src.[CountryName], 
            [StateProvinceID] = Src.[StateProvinceID], 
            [StateProvinceName] = Src.[StateProvinceName], 
            [CityName] = Src.[CityName], 
            [CountyName] = Src.[CountyName], 
            [ZipCode] = Src.[ZipCode], 
            [IsCurrent] = Src.[IsCurrent], 
            [FromDate] = Src.[FromDate], 
            [ToDate] = Src.[ToDate], 
            [RowChangeReason] = Src.[RowChangeReason], 
            [InsertAuditKey] = Src.[InsertAuditKey], 
            [UpdateAuditKey] = Src.[UpdateAuditKey], 
            [HashKey] = Src.[HashKey], 
            [HashNonKey] = Src.[HashNonKey]

      
     -- Delete condition (skip default)
     WHEN NOT MATCHED BY SOURCE AND (Trg.[AddressKey] <> -1) THEN 
         UPDATE SET
		    [IsCurrent] = 0
			
     -- Insert condition
     WHEN NOT MATCHED BY TARGET THEN
         INSERT
         (
            [AddressID], 
            [AddressLine1], 
            [Street], 
            [CountryID], 
            [CountryName], 
            [StateProvinceID], 
            [StateProvinceName], 
            [CityName], 
            [CountyName], 
            [ZipCode], 
            [IsCurrent], 
            [FromDate], 
            [ToDate], 
            [RowChangeReason], 
            [InsertAuditKey], 
            [UpdateAuditKey], 
            [HashKey], 
            [HashNonKey]
         )
         VALUES
         ( 
            Src.[AddressID], 
            Src.[AddressLine1], 
            Src.[Street], 
            Src.[CountryID], 
            Src.[CountryName], 
            Src.[StateProvinceID], 
            Src.[StateProvinceName], 
            Src.[CityName], 
            Src.[CountyName], 
            Src.[ZipCode], 
            Src.[IsCurrent], 
            Src.[FromDate], 
            Src.[ToDate], 
            Src.[RowChangeReason], 
            Src.[InsertAuditKey], 
            Src.[UpdateAuditKey], 
            Src.[HashKey], 
            Src.[HashNonKey]
         );
 
 GO
