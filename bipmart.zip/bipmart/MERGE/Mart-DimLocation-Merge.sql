/******************************************************
  *
  * Name:         Mart-DimLocation-Merge.sql
  *     
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-01-2018
  *     Purpose:  Merge [DimLocation] table data
  *               in [Stage] with data in [Mart].
  * 
  ******************************************************/
 
 CREATE PROCEDURE [Mart].[MergeDimLocation]
 AS
 
     -- Merge between Target & Source
     MERGE 
         [Mart].[DimLocation] AS Trg
     USING 
     (
         SELECT * FROM [Stage].[DimLocation]
     ) AS Src ON Src.[HashKey] = Trg.[HashKey] 
 
     -- Update condition
     WHEN MATCHED AND (Src.HashNonKey <> Trg.HashNonKey) THEN 
         UPDATE SET
            [LocationKey] = Src.[LocationKey], 
            [LocationID] = Src.[LocationID], 
            [LocationName] = Src.[LocationName], 
            [SiteID] = Src.[SiteID], 
            [SiteName] = Src.[SiteName], 
            [CompanyKey] = Src.[CompanyKey], 
            [IsCurrent] = Src.[IsCurrent], 
            [FromDate] = Src.[FromDate], 
            [ToDate] = Src.[ToDate], 
            [RowChangeReason] = Src.[RowChangeReason], 
            [InsertAuditKey] = Src.[InsertAuditKey], 
            [UpdateAuditKey] = Src.[UpdateAuditKey], 
            [HashKey] = Src.[HashKey], 
            [HashNonKey] = Src.[HashNonKey]

      
     -- Delete condition (skip default)
     WHEN NOT MATCHED BY SOURCE AND (Trg.[LocationKey] <> -1) THEN
	     UPDATE SET
	        [IsCurrent = 0]
	 		  
     -- Insert condition
	WHEN NOT MATCHED BY TARGET THEN
     	 INSERT
         (
            [LocationKey], 
            [LocationID], 
            [LocationName], 
            [SiteID], 
            [SiteName], 
            [CompanyKey], 
            [IsCurrent], 
            [FromDate], 
            [ToDate], 
            [RowChangeReason], 
            [InsertAuditKey], 
            [UpdateAuditKey], 
            [HashKey], 
            [HashNonKey]
         )
         VALUES
         ( 
            Src.[LocationKey], 
            Src.[LocationID], 
            Src.[LocationName], 
            Src.[SiteID], 
            Src.[SiteName], 
            Src.[CompanyKey], 
            Src.[IsCurrent], 
            Src.[FromDate], 
            Src.[ToDate], 
            Src.[RowChangeReason], 
            Src.[InsertAuditKey], 
            Src.[UpdateAuditKey], 
            Src.[HashKey], 
            Src.[HashNonKey]
         );
  GO
