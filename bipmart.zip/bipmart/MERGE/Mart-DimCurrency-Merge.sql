/******************************************************
  *
  * Name:         Mart-DimCurrency-Merge.sql
  *     
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-01-2018
  *     Purpose:  Merge [DimCurrency] table data
  *               in [Stage] with data in [Mart].
  * 
  ******************************************************/
 
 CREATE PROCEDURE [Mart].[MergeDimCurrency]
 AS
 
     -- Merge between Target & Source
     MERGE 
         [Mart].[DimCurrency] AS Trg
     USING 
     (
         SELECT * FROM [Stage].[DimCurrency]
     ) AS Src ON Src.[HashKey] = Trg.[HashKey] 
 
     -- Update condition
     WHEN MATCHED AND (Src.HashNonKey <> Trg.HashNonKey) THEN 
         UPDATE SET
            [CurrencyKey] = Src.[CurrencyKey], 
            [CurrencyID] = Src.[CurrencyID], 
            [CurrencyName] = Src.[CurrencyName], 
            [IsCurrent] = Src.[IsCurrent], 
            [FromDate] = Src.[FromDate], 
            [ToDate] = Src.[ToDate], 
            [RowChangeReason] = Src.[RowChangeReason], 
            [InsertAuditKey] = Src.[InsertAuditKey], 
            [UpdateAuditKey] = Src.[UpdateAuditKey], 
            [HashKey] = Src.[HashKey], 
            [HashNonKey] = Src.[HashNonKey]

      
     -- Delete condition (skip default)
     WHEN NOT MATCHED BY SOURCE AND (Trg.[CurrencyKey] <> -1) THEN
	         UPDATE SET
		         [IsCurrent] = 0
 
     -- Insert condition
     WHEN NOT MATCHED BY TARGET THEN
         INSERT
         (
            [CurrencyKey], 
            [CurrencyID], 
            [CurrencyName], 
            [IsCurrent], 
            [FromDate], 
            [ToDate], 
            [RowChangeReason], 
            [InsertAuditKey], 
            [UpdateAuditKey], 
            [HashKey], 
            [HashNonKey]
         )
         VALUES
         ( 
            Src.[CurrencyKey], 
            Src.[CurrencyID], 
            Src.[CurrencyName], 
            Src.[IsCurrent], 
            Src.[FromDate], 
            Src.[ToDate], 
            Src.[RowChangeReason], 
            Src.[InsertAuditKey], 
            Src.[UpdateAuditKey], 
            Src.[HashKey], 
            Src.[HashNonKey]
         );
 
 GO
