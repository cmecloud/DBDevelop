/******************************************************
  *
  * Name:         Mart-DimLedgerTransaction-Merge.sql
  *     
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-01-2018
  *     Purpose:  Merge [DimLedgerTransaction] table data
  *               in [Stage] with data in [Mart].
  * 
  ******************************************************/
 
 CREATE PROCEDURE [Mart].[MergeDimLedgerTransaction]
 AS
 
     -- Merge between Target & Source
     MERGE 
         [Mart].[DimLedgerTransaction] AS Trg
     USING 
     (
         SELECT * FROM [Stage].[DimLedgerTransaction]
     ) AS Src ON Src.[HashKey] = Trg.[HashKey] 
 
     -- Update condition
     WHEN MATCHED AND (Src.HashNonKey <> Trg.HashNonKey) THEN 
         UPDATE SET
            [LedgerTransactionKey] = Src.[LedgerTransactionKey], 
            [LedgerTransactionType] = Src.[LedgerTransactionType], 
            [LedgerTransactionTypeName] = Src.[LedgerTransactionTypeName], 
            [LedgerPostingTypeID] = Src.[LedgerPostingTypeID], 
            [LedgerPostingTypeName] = Src.[LedgerPostingTypeName], 
            [RowChangeReason] = Src.[RowChangeReason], 
            [InsertAuditKey] = Src.[InsertAuditKey], 
            [UpdateAuditKey] = Src.[UpdateAuditKey], 
            [HashKey] = Src.[HashKey], 
            [HashNonKey] = Src.[HashNonKey]

      
     -- Delete condition (skip default)
     WHEN NOT MATCHED BY SOURCE AND (Trg.[LedgerTransactionKey] <> -1) THEN DELETE
 
     -- Insert condition
     WHEN NOT MATCHED BY TARGET THEN
         INSERT
         (
            [LedgerTransactionKey], 
            [LedgerTransactionType], 
            [LedgerTransactionTypeName], 
            [LedgerPostingTypeID], 
            [LedgerPostingTypeName], 
            [RowChangeReason], 
            [InsertAuditKey], 
            [UpdateAuditKey], 
            [HashKey], 
            [HashNonKey]
         )
         VALUES
         ( 
            Src.[LedgerTransactionKey], 
            Src.[LedgerTransactionType], 
            Src.[LedgerTransactionTypeName], 
            Src.[LedgerPostingTypeID], 
            Src.[LedgerPostingTypeName], 
            Src.[RowChangeReason], 
            Src.[InsertAuditKey], 
            Src.[UpdateAuditKey], 
            Src.[HashKey], 
            Src.[HashNonKey]
         );
 
 GO
