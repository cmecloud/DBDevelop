/******************************************************
  *
  * Name:         Mart-FactLedgerBalance-Merge.sql
  *     
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-01-2018
  *     Purpose:  Merge [FactLedgerBalance] table data
  *               in [Stage] with data in [Mart].
  * 
  ******************************************************/
 
 CREATE PROCEDURE [Mart].[MergeFactLedgerBalance]
 AS
 
     -- Merge between Target & Source
     MERGE 
         [Mart].[FactLedgerBalance] AS Trg
     USING 
     (
         SELECT * FROM [Stage].[FactLedgerBalance]
     ) AS Src ON Src.[HashKey] = Trg.[HashKey] 
 
     -- Update condition
     WHEN MATCHED AND (Src.HashNonKey <> Trg.HashNonKey) THEN 
         UPDATE SET
            [FactLedgerBalanceKey] = Src.[FactLedgerBalanceKey], 
            [DateKey] = Src.[DateKey], 
            [CompanyKey] = Src.[CompanyKey], 
            [AccountKey] = Src.[AccountKey], 
            [LedgerTransactionKey] = Src.[LedgerTransactionKey], 
            [TransactionKey] = Src.[TransactionKey], 
            [InsertAuditKey] = Src.[InsertAuditKey], 
            [UpdateAuditKey] = Src.[UpdateAuditKey], 
            [DebitAmount] = Src.[DebitAmount], 
            [CreditAmount] = Src.[CreditAmount], 
            [Quantity] = Src.[Quantity], 
            [HashKey] = Src.[HashKey], 
            [HashNonKey] = Src.[HashNonKey]

      
     -- Delete condition (skip default)
     WHEN NOT MATCHED BY SOURCE AND (Trg.[FactLedgerBalanceKey] <> -1) THEN DELETE
 
     -- Insert condition
     WHEN NOT MATCHED BY TARGET THEN
         INSERT
         (
            [FactLedgerBalanceKey], 
            [DateKey], 
            [CompanyKey], 
            [AccountKey], 
            [LedgerTransactionKey], 
            [TransactionKey], 
            [InsertAuditKey], 
            [UpdateAuditKey], 
            [DebitAmount], 
            [CreditAmount], 
            [Quantity], 
            [HashKey], 
            [HashNonKey]
         )
         VALUES
         ( 
            Src.[FactLedgerBalanceKey], 
            Src.[DateKey], 
            Src.[CompanyKey], 
            Src.[AccountKey], 
            Src.[LedgerTransactionKey], 
            Src.[TransactionKey], 
            Src.[InsertAuditKey], 
            Src.[UpdateAuditKey], 
            Src.[DebitAmount], 
            Src.[CreditAmount], 
            Src.[Quantity], 
            Src.[HashKey], 
            Src.[HashNonKey]
         );
 
 GO
