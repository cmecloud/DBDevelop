/******************************************************
  *
  * Name:         Mart-FactExchangeRate-Merge.sql
  *     
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-01-2018
  *     Purpose:  Merge [FactExchangeRate] table data
  *               in [Stage] with data in [Mart].
  * 
  ******************************************************/
 
 CREATE PROCEDURE [Mart].[MergeFactExchangeRate]
 AS
 
     -- Merge between Target & Source
     MERGE 
         [Mart].[FactExchangeRate] AS Trg
     USING 
     (
         SELECT * FROM [Stage].[FactExchangeRate]
     ) AS Src ON Src.[HashKey] = Trg.[HashKey] 
 
     -- Update condition
     WHEN MATCHED AND (Src.HashNonKey <> Trg.HashNonKey) THEN 
         UPDATE SET
            [FactExchangeRateKey] = Src.[FactExchangeRateKey], 
            [DateKey] = Src.[DateKey], 
            [SourceCurrencyKey] = Src.[SourceCurrencyKey], 
            [DestinationCurrencyKey] = Src.[DestinationCurrencyKey], 
            [ExchangeRate] = Src.[ExchangeRate], 
            [InsertAuditKey] = Src.[InsertAuditKey], 
            [UpdateAuditKey] = Src.[UpdateAuditKey], 
            [HashKey] = Src.[HashKey], 
            [HashNonKey] = Src.[HashNonKey]

      
     -- Delete condition (skip default)
     WHEN NOT MATCHED BY SOURCE AND (Trg.[FactExchangeRateKey] <> -1) THEN DELETE
 
     -- Insert condition
     WHEN NOT MATCHED BY TARGET THEN
         INSERT
         (
            [FactExchangeRateKey], 
            [DateKey], 
            [SourceCurrencyKey], 
            [DestinationCurrencyKey], 
            [ExchangeRate], 
            [InsertAuditKey], 
            [UpdateAuditKey], 
            [HashKey], 
            [HashNonKey]
         )
         VALUES
         ( 
            Src.[FactExchangeRateKey], 
            Src.[DateKey], 
            Src.[SourceCurrencyKey], 
            Src.[DestinationCurrencyKey], 
            Src.[ExchangeRate], 
            Src.[InsertAuditKey], 
            Src.[UpdateAuditKey], 
            Src.[HashKey], 
            Src.[HashNonKey]
         );
 
 GO
