/******************************************************
  *
  * Name:         Mart-DimLedgerAccount-Merge.sql
  *     
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-01-2018
  *     Purpose:  Merge [DimLedgerAccount] table data
  *               in [Stage] with data in [Mart].
  * 
  ******************************************************/
 
 CREATE PROCEDURE [Mart].[MergeDimLedgerAccount]
 AS
 
     -- Merge between Target & Source
     MERGE 
         [Mart].[DimLedgerAccount] AS Trg
     USING 
     (
         SELECT * FROM [Stage].[DimLedgerAccount]
     ) AS Src ON Src.[HashKey] = Trg.[HashKey] 
 
     -- Update condition
     WHEN MATCHED AND (Src.HashNonKey <> Trg.HashNonKey) THEN 
         UPDATE SET
            [AccountKey] = Src.[AccountKey], 
            [AccountID] = Src.[AccountID], 
            [AccountNumber] = Src.[AccountNumber], 
            [AccountName] = Src.[AccountName], 
            [AccountGroup] = Src.[AccountGroup], 
            [AccountType] = Src.[AccountType], 
            [ParentAccountID] = Src.[ParentAccountID], 
            [CompanyKey] = Src.[CompanyKey], 
            [AggregationBehavior] = Src.[AggregationBehavior], 
            [AggregationOperator] = Src.[AggregationOperator], 
            [Unit] = Src.[Unit], 
            [IsExcludedDPO] = Src.[IsExcludedDPO], 
            [IsMovementAllowed] = Src.[IsMovementAllowed], 
            [IsLocked] = Src.[IsLocked], 
            [IsClosed] = Src.[IsClosed], 
            [IsSales] = Src.[IsSales], 
            [IsNewOrders] = Src.[IsNewOrders], 
            [IsBacklog] = Src.[IsBacklog], 
            [IsOverhead] = Src.[IsOverhead], 
            [IsCurrent] = Src.[IsCurrent], 
            [FromDate] = Src.[FromDate], 
            [ToDate] = Src.[ToDate], 
            [RowChangeReason] = Src.[RowChangeReason], 
            [InsertAuditKey] = Src.[InsertAuditKey], 
            [UpdateAuditKey] = Src.[UpdateAuditKey], 
            [HashKey] = Src.[HashKey], 
            [HashNonKey] = Src.[HashNonKey]

      
     -- Delete condition (skip default)
     WHEN NOT MATCHED BY SOURCE AND (Trg.[AccountKey] <> -1) THEN
	     UPDATE SET
		         [IsCurrent] = 0
 
     -- Insert condition
     WHEN NOT MATCHED BY TARGET THEN
         INSERT
         (
            [AccountKey], 
            [AccountID], 
            [AccountNumber], 
            [AccountName], 
            [AccountGroup], 
            [AccountType], 
            [ParentAccountID], 
            [CompanyKey], 
            [AggregationBehavior], 
            [AggregationOperator], 
            [Unit], 
            [IsExcludedDPO], 
            [IsMovementAllowed], 
            [IsLocked], 
            [IsClosed], 
            [IsSales], 
            [IsNewOrders], 
            [IsBacklog], 
            [IsOverhead], 
            [IsCurrent], 
            [FromDate], 
            [ToDate], 
            [RowChangeReason], 
            [InsertAuditKey], 
            [UpdateAuditKey], 
            [HashKey], 
            [HashNonKey]
         )
         VALUES
         ( 
            Src.[AccountKey], 
            Src.[AccountID], 
            Src.[AccountNumber], 
            Src.[AccountName], 
            Src.[AccountGroup], 
            Src.[AccountType], 
            Src.[ParentAccountID], 
            Src.[CompanyKey], 
            Src.[AggregationBehavior], 
            Src.[AggregationOperator], 
            Src.[Unit], 
            Src.[IsExcludedDPO], 
            Src.[IsMovementAllowed], 
            Src.[IsLocked], 
            Src.[IsClosed], 
            Src.[IsSales], 
            Src.[IsNewOrders], 
            Src.[IsBacklog], 
            Src.[IsOverhead], 
            Src.[IsCurrent], 
            Src.[FromDate], 
            Src.[ToDate], 
            Src.[RowChangeReason], 
            Src.[InsertAuditKey], 
            Src.[UpdateAuditKey], 
            Src.[HashKey], 
            Src.[HashNonKey]
         );
 
 GO
