/******************************************************
  *
  * Name:         Mart-DimCompany-Merge.sql
  *     
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-01-2018
  *     Purpose:  Merge [DimCompany] table data
  *               in [Stage] with data in [Mart].
  * 
  ******************************************************/
 
 CREATE PROCEDURE [Mart].[MergeDimCompany]
 AS
 
     -- Merge between Target & Source
     MERGE 
         [Mart].[DimCompany] AS Trg
     USING 
     (
         SELECT * FROM [Stage].[DimCompany]
     ) AS Src ON Src.[HashKey] = Trg.[HashKey] 
 
     -- Update condition
     WHEN MATCHED AND (Src.HashNonKey <> Trg.HashNonKey) THEN 
         UPDATE SET
            [CompanyKey] = Src.[CompanyKey], 
            [CompanyID] = Src.[CompanyID], 
            [Company] = Src.[Company], 
            [SubRegion] = Src.[SubRegion], 
            [Region] = Src.[Region], 
            [ProductLine] = Src.[ProductLine], 
            [CollectionType] = Src.[CollectionType], 
            [CompanyAddress] = Src.[CompanyAddress], 
            [CurrencyKey] = Src.[CurrencyKey], 
            [CurrentCompanyKey] = Src.[CurrentCompanyKey], 
            [IsClosed] = Src.[IsClosed], 
            [IsCurrent] = Src.[IsCurrent], 
            [FromDate] = Src.[FromDate], 
            [ToDate] = Src.[ToDate], 
            [RowChangeReason] = Src.[RowChangeReason], 
            [InsertAuditKey] = Src.[InsertAuditKey], 
            [UpdateAuditKey] = Src.[UpdateAuditKey], 
            [HashKey] = Src.[HashKey], 
            [HashNonKey] = Src.[HashNonKey]

      
     -- Delete condition (skip default)
     WHEN NOT MATCHED BY SOURCE AND (Trg.[CompanyKey] <> -1) THEN
	          UPDATE SET
		         [IsCurrent] = 0
 
     -- Insert condition
     WHEN NOT MATCHED BY TARGET THEN
         INSERT
         (
            [CompanyKey], 
            [CompanyID], 
            [Company], 
            [SubRegion], 
            [Region], 
            [ProductLine], 
            [CollectionType], 
            [CompanyAddress], 
            [CurrencyKey], 
            [CurrentCompanyKey], 
            [IsClosed], 
            [IsCurrent], 
            [FromDate], 
            [ToDate], 
            [RowChangeReason], 
            [InsertAuditKey], 
            [UpdateAuditKey], 
            [HashKey], 
            [HashNonKey]
         )
         VALUES
         ( 
            Src.[CompanyKey], 
            Src.[CompanyID], 
            Src.[Company], 
            Src.[SubRegion], 
            Src.[Region], 
            Src.[ProductLine], 
            Src.[CollectionType], 
            Src.[CompanyAddress], 
            Src.[CurrencyKey],
            Src.[CurrentCompanyKey], 
            Src.[IsClosed], 
            Src.[IsCurrent], 
            Src.[FromDate], 
            Src.[ToDate], 
            Src.[RowChangeReason], 
            Src.[InsertAuditKey], 
            Src.[UpdateAuditKey], 
            Src.[HashKey], 
            Src.[HashNonKey]
         );
 
 GO
