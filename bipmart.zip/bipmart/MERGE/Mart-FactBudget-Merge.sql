/******************************************************
  *
  * Name:         Mart-FactBudget-Merge.sql
  *     
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-01-2018
  *     Purpose:  Merge [FactBudget] table data
  *               in [Stage] with data in [Mart].
  * 
  ******************************************************/
 
 CREATE PROCEDURE [Mart].[MergeFactBudget]
 AS
 
     -- Merge between Target & Source
     MERGE 
         [Mart].[FactBudget] AS Trg
     USING 
     (
         SELECT * FROM [Stage].[FactBudget]
     ) AS Src ON Src.[HashKey] = Trg.[HashKey] 
 
     -- Update condition
     WHEN MATCHED AND (Src.HashNonKey <> Trg.HashNonKey) THEN 
         UPDATE SET
            [FactBudgetKey] = Src.[FactBudgetKey], 
            [DateKey] = Src.[DateKey], 
            [CompanyKey] = Src.[CompanyKey], 
            [AccountKey] = Src.[AccountKey], 
            [TransactionKey] = Src.[TransactionKey], 
            [InsertAuditKey] = Src.[InsertAuditKey], 
            [UpdateAuditKey] = Src.[UpdateAuditKey], 
            [ModelNumber] = Src.[ModelNumber], 
            [BudgetAmount] = Src.[BudgetAmount], 
            [Quantity] = Src.[Quantity], 
            [HashKey] = Src.[HashKey], 
            [HashNonKey] = Src.[HashNonKey]

      
     -- Delete condition (skip default)
     WHEN NOT MATCHED BY SOURCE AND (Trg.[FactBudgetKey] <> -1) THEN DELETE
 
     -- Insert condition
     WHEN NOT MATCHED BY TARGET THEN
         INSERT
         (
            [FactBudgetKey], 
            [DateKey], 
            [CompanyKey], 
            [AccountKey], 
            [TransactionKey], 
            [InsertAuditKey], 
            [UpdateAuditKey], 
            [ModelNumber], 
            [BudgetAmount], 
            [Quantity], 
            [HashKey], 
            [HashNonKey]
         )
         VALUES
         ( 
            Src.[FactBudgetKey], 
            Src.[DateKey], 
            Src.[CompanyKey], 
            Src.[AccountKey], 
            Src.[TransactionKey], 
            Src.[InsertAuditKey], 
            Src.[UpdateAuditKey], 
            Src.[ModelNumber], 
            Src.[BudgetAmount], 
            Src.[Quantity], 
            Src.[HashKey], 
            Src.[HashNonKey]
         );
 
 GO
