/******************************************************
  *
  * Name:         Mart-DimDate-Merge.sql
  *     
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-01-2018
  *     Purpose:  Merge [DimDate] table data
  *               in [Stage] with data in [Mart].
  * 
  ******************************************************/
 
 CREATE PROCEDURE [Mart].[MergeDimDate]
 AS
 
     -- Merge between Target & Source
     MERGE 
         [Mart].[DimDate] AS Trg
     USING 
     (
         SELECT * FROM [Stage].[DimDate]
     ) AS Src ON Src.[HashKey] = Trg.[HashKey] 
 
     -- Update condition
     WHEN MATCHED AND (Src.HashNonKey <> Trg.HashNonKey) THEN 
         UPDATE SET
            [DateKey] = Src.[DateKey], 
            [DateName] = Src.[DateName], 
            [DateLongName] = Src.[DateLongName], 
            [FiscalDayNumber] = Src.[FiscalDayNumber], 
            [FiscalMonthID] = Src.[FiscalMonthID], 
            [FiscalMonthNumber] = Src.[FiscalMonthNumber], 
            [FiscalMonthName] = Src.[FiscalMonthName], 
            [FiscalMonthBegin] = Src.[FiscalMonthBegin], 
            [FiscalMonthEnd] = Src.[FiscalMonthEnd], 
            [FiscalWeekNumber] = Src.[FiscalWeekNumber], 
            [FiscalWeekName] = Src.[FiscalWeekName], 
            [FiscalWeekBegin] = Src.[FiscalWeekBegin], 
            [FiscalWeekEnd] = Src.[FiscalWeekEnd], 
            [FiscalDayOfWeek] = Src.[FiscalDayOfWeek], 
            [FiscalQuarterID] = Src.[FiscalQuarterID], 
            [FiscalQuarterNumber] = Src.[FiscalQuarterNumber], 
            [FiscalQuarterName] = Src.[FiscalQuarterName], 
            [FiscalQuarterBegin] = Src.[FiscalQuarterBegin], 
            [FiscalQuarterEnd] = Src.[FiscalQuarterEnd], 
            [FiscalDayOfQuarter] = Src.[FiscalDayOfQuarter], 
            [FiscalYear] = Src.[FiscalYear], 
            [FiscalYearBegin] = Src.[FiscalYearBegin], 
            [FiscalYearEnd] = Src.[FiscalYearEnd], 
            [FiscalDayOfYear] = Src.[FiscalDayOfYear], 
            [IsCurrent] = Src.[IsCurrent],
			[FromDate] = Src.[FromDate], 
            [ToDate] = Src.[ToDate], 
            [RowChangeReason] = Src.[RowChangeReason], 
            [InsertAuditKey] = Src.[InsertAuditKey], 
            [UpdateAuditKey] = Src.[UpdateAuditKey], 
            [HashKey] = Src.[HashKey], 
            [HashNonKey] = Src.[HashNonKey]

      
     -- Delete condition (skip default)
      WHEN NOT MATCHED BY SOURCE AND (Trg.[DateKey] <> -1) THEN 
         UPDATE SET
		    [IsCurrent] = 0

     -- Insert condition
     WHEN NOT MATCHED BY TARGET THEN
         INSERT
         (
            [DateKey], 
            [DateName], 
            [DateLongName], 
            [FiscalDayNumber], 
            [FiscalMonthID], 
            [FiscalMonthNumber], 
            [FiscalMonthName], 
            [FiscalMonthBegin], 
            [FiscalMonthEnd], 
            [FiscalWeekNumber], 
            [FiscalWeekName], 
            [FiscalWeekBegin], 
            [FiscalWeekEnd], 
            [FiscalDayOfWeek], 
            [FiscalQuarterID], 
            [FiscalQuarterNumber], 
            [FiscalQuarterName], 
            [FiscalQuarterBegin], 
            [FiscalQuarterEnd], 
            [FiscalDayOfQuarter], 
            [FiscalYear], 
            [FiscalYearBegin], 
            [FiscalYearEnd], 
            [FiscalDayOfYear], 
            [IsCurrent],
			[FromDate],
			[ToDate],
			[RowChangeReason],
            [InsertAuditKey], 
            [UpdateAuditKey], 
            [HashKey], 
            [HashNonKey]
         )
         VALUES
         ( 
            Src.[DateKey], 
            Src.[DateName], 
            Src.[DateLongName], 
            Src.[FiscalDayNumber], 
            Src.[FiscalMonthID], 
            Src.[FiscalMonthNumber], 
            Src.[FiscalMonthName], 
            Src.[FiscalMonthBegin], 
            Src.[FiscalMonthEnd], 
            Src.[FiscalWeekNumber], 
            Src.[FiscalWeekName], 
            Src.[FiscalWeekBegin], 
            Src.[FiscalWeekEnd], 
            Src.[FiscalDayOfWeek], 
            Src.[FiscalQuarterID], 
            Src.[FiscalQuarterNumber], 
            Src.[FiscalQuarterName], 
            Src.[FiscalQuarterBegin], 
            Src.[FiscalQuarterEnd], 
            Src.[FiscalDayOfQuarter], 
            Src.[FiscalYear], 
            Src.[IsCurrent],
			Src.[FromDate],
			Src.[ToDate],
			Src.[RowChangeReason],
            Src.[InsertAuditKey], 
            Src.[UpdateAuditKey], 
            Src.[HashKey], 
            Src.[HashNonKey]
         );
 
 GO
