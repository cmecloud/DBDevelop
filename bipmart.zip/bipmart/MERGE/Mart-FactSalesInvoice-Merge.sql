/******************************************************
  *
  * Name:         Mart-FactSalesInvoice-Merge.sql
  *     
  * Design Phase:
  *     Author:   System Generated.
  *     Date:     07-01-2018
  *     Purpose:  Merge [FactSalesInvoice] table data
  *               in [Stage] with data in [Mart].
  * 
  ******************************************************/
 
 CREATE PROCEDURE [Mart].[MergeFactSalesInvoice]
 AS
 
     -- Merge between Target & Source
     MERGE 
         [Mart].[FactSalesInvoice] AS Trg
     USING 
     (
         SELECT * FROM [Stage].[FactSalesInvoice]
     ) AS Src ON Src.[HashKey] = Trg.[HashKey] 
 
     -- Update condition
     WHEN MATCHED AND (Src.HashNonKey <> Trg.HashNonKey) THEN 
         UPDATE SET
            [FactSalesInvoiceKey] = Src.[FactSalesInvoiceKey], 
            [LocationKey] = Src.[LocationKey], 
            [CustomerKey] = Src.[CustomerKey], 
            [OrderCustomerKey] = Src.[OrderCustomerKey], 
            [EndCustomerKey] = Src.[EndCustomerKey], 
            [ItemKey] = Src.[ItemKey], 
            [SalesGroupKey] = Src.[SalesGroupKey], 
            [InvoiceDateKey] = Src.[InvoiceDateKey], 
            [InvoiceDueDateKey] = Src.[InvoiceDueDateKey], 
            [DeliveryDateKey] = Src.[DeliveryDateKey], 
            [CurrencyKey] = Src.[CurrencyKey], 
            [DeliveryAddressKey] = Src.[DeliveryAddressKey], 
            [TransactionKey] = Src.[TransactionKey], 
            [InsertAuditKey] = Src.[InsertAuditKey], 
            [UpdateAuditKey] = Src.[UpdateAuditKey], 
            [SalesOrderNumber] = Src.[SalesOrderNumber], 
            [InvoiceNumber] = Src.[InvoiceNumber], 
            [IsSpecial] = Src.[IsSpecial], 
            [IsSpecialInSpecial] = Src.[IsSpecialInSpecial], 
            [DeliveryTerms] = Src.[DeliveryTerms], 
            [DeliveryMode] = Src.[DeliveryMode], 
            [CommissionGroup] = Src.[CommissionGroup], 
            [Amount] = Src.[Amount], 
            [Unit] = Src.[Unit], 
            [Quanity] = Src.[Quanity], 
            [Commission] = Src.[Commission], 
            [TaxAmount] = Src.[TaxAmount], 
            [TotalCost] = Src.[TotalCost], 
            [UnitPrice] = Src.[UnitPrice], 
            [UnitCost] = Src.[UnitCost], 
            [Discount] = Src.[Discount], 
            [Freight] = Src.[Freight], 
            [FreightCost] = Src.[FreightCost], 
            [OverheadCostPct] = Src.[OverheadCostPct], 
            [EngineeringHours] = Src.[EngineeringHours], 
            [LaborHours] = Src.[LaborHours], 
            [HashKey] = Src.[HashKey], 
            [HashNonKey] = Src.[HashNonKey]

      
     -- Delete condition (skip default)
     WHEN NOT MATCHED BY SOURCE AND (Trg.[FactSalesInvoiceKey] <> -1) THEN DELETE
 
     -- Insert condition
     WHEN NOT MATCHED BY TARGET THEN
         INSERT
         (
            [FactSalesInvoiceKey], 
            [LocationKey], 
            [CustomerKey], 
            [OrderCustomerKey], 
            [EndCustomerKey], 
            [ItemKey], 
            [SalesGroupKey], 
            [InvoiceDateKey], 
            [InvoiceDueDateKey], 
            [DeliveryDateKey], 
            [CurrencyKey], 
            [DeliveryAddressKey], 
            [TransactionKey], 
            [InsertAuditKey], 
            [UpdateAuditKey], 
            [SalesOrderNumber], 
            [InvoiceNumber], 
            [IsSpecial], 
            [IsSpecialInSpecial], 
            [DeliveryTerms], 
            [DeliveryMode], 
            [CommissionGroup], 
            [Amount], 
            [Unit], 
            [Quanity], 
            [Commission], 
            [TaxAmount], 
            [TotalCost], 
            [UnitPrice], 
            [UnitCost], 
            [Discount], 
            [Freight], 
            [FreightCost], 
            [OverheadCostPct], 
            [EngineeringHours], 
            [LaborHours], 
            [HashKey], 
            [HashNonKey]
         )
         VALUES
         ( 
            Src.[FactSalesInvoiceKey], 
            Src.[LocationKey], 
            Src.[CustomerKey], 
            Src.[OrderCustomerKey], 
            Src.[EndCustomerKey], 
            Src.[ItemKey], 
            Src.[SalesGroupKey], 
            Src.[InvoiceDateKey], 
            Src.[InvoiceDueDateKey], 
            Src.[DeliveryDateKey], 
            Src.[CurrencyKey], 
            Src.[DeliveryAddressKey], 
            Src.[TransactionKey], 
            Src.[InsertAuditKey], 
            Src.[UpdateAuditKey], 
            Src.[SalesOrderNumber], 
            Src.[InvoiceNumber], 
            Src.[IsSpecial], 
            Src.[IsSpecialInSpecial], 
            Src.[DeliveryTerms], 
            Src.[DeliveryMode], 
            Src.[CommissionGroup], 
            Src.[Amount], 
            Src.[Unit], 
            Src.[Quanity], 
            Src.[Commission], 
            Src.[TaxAmount], 
            Src.[TotalCost], 
            Src.[UnitPrice], 
            Src.[UnitCost], 
            Src.[Discount], 
            Src.[Freight], 
            Src.[FreightCost], 
            Src.[OverheadCostPct], 
            Src.[EngineeringHours], 
            Src.[LaborHours], 
            Src.[HashKey], 
            Src.[HashNonKey]
         );
 
 GO
